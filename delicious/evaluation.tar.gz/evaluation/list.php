<h2>online</h2>
<ol>
<li>
<span style="background-color: red">
<a target="link" href="http://www.busca-cuit.com.ar/">Buscar CUIT por nombre, razón social o DNI, actualizado al 02/07/2010</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.apostouganhou.com/br/bingo-games.aspx">jogos de bingo online, bingo games jackpots</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.bildwoerterbuch.com/">Bildwörterbuch</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.shapefit.com/">سایتی درباره بدنسازی</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.bebestore.com.br/">BEBÊ STORE</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.intelligencetest.com/">IQ Test Labs - free online testing.</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.impactfolios.com/">Online Portfolio Websites - ImpactFolios</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.rtve.es/alacarta/">RTVE.es A la Carta, televisión y radio online gratis</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.sweethome3d.com/importModels.jsp">Sweet Home 3D : 3D models import</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.dietasan.com/">Calculadora dietética - DietaSan.com</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.sitepoint.com/blogs/2009/05/21/tools-manage-online-reputation/">Online Reputation Management: 16 Free Tools</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://loomn.it/index.php">Loomnit - The easiest way to share anything on the web.</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.netzathleten.de/">Sportmagazin - Das Online-Magazin rund um den Sport | netzathleten</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.namestation.com/">NameStation - Name Ideas, Domain Name Search, Naming Contests</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://jpn.icicom.up.pt/">jpn</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.regexpal.com/">Regex Tester – RegexPal</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.dbnl.org/index.php">dbnl · digitale bibliotheek voor de Nederlandse letteren</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.seriesyonkis.com/serie/mujeres-desesperadas/">Mujeres Desesperadas online @ Serie</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.techsmith.com/community/education/default.asp">Education Community - TechSmith, the world leader in Screen Capture and Screen Recording Software.</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://iprelovedreloved.wordpress.com/">iprelovedreloved | Just another WordPress.com site</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.jobtopgun.com/">jobtopgun</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://juanmacias.net/archives/1335">SEO: El contenido ya no es el rey</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.humanmetrics.com/cgi-win/jtypes2.asp">Personality test based on Jung and Briggs Myers typology</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.start-vpn.com/">Consumer reviews of personal VPN services | START-vpn.com</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.cleartrip.com/smallworld">Small World | Worldwide travel guides from Cleartrip</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://artpad.art.com/artpad/painter/">art.com artPad</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.edwinjagger.com/">EdwinJagger.com : Razors, Shaving brushes, Shaving Sets & Cut Throat Razors, Shaving Creams, Shaving Soaps, Aftershave Lotion,</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.forexpeacearmy.com/">Free Forex Trading Community With Forex Signals And Broker ...</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.proposalkit.com/">Proposal and Contract Management Software, Documents, Templates and Samples for Selling Products and Services</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.cartosoft.com/mapicons/">mapicon Factory by CartoSoft > Home</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.motorcycle.com/index.html">Motorcycle Reviews, Videos, Prices and Used Motorcycles</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.amconmag.com/index.html">The American Conservative</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.buddymeeting.com/index.php">Best Web Conference | The Buddy Meeting Website Provides The Best Free Web Conferencing Services</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.bitstrips.com/about.php">Bitstrips: About Us</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.ibackup.com/index.html">IBackup - Online Backup, Online Storage and Data Sharing</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="https://www.limeservice.com/">LimeService - The official LimeSurvey hosting platform</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.w3.org/WAI/ER/tools/complete">Complete List of Web Accessibility Evaluation Tools</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.eltenedor.es/">Restaurante Madrid, Barcelona | ElTenedor | Reservar restaurantes Madrid</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.1-day.com.au/">1-day - One Day 3 Great Deals, Today Only! Daily Deals</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bruzzesi.com/">Marcelo Bruzzesi - Art Director</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.ocf.berkeley.edu/~jjlin/jsotp/">jsotp: JavaScript OTP & S/Key Calculator</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.wisc-online.com/">Welcome to Wisc-Online.com</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://buttonbeats.com/">Button Beats Make Music online. Play the Virtual Piano.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sdccu.com/pages/home/index.asp">San Diego County Credit Union</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="https://www.tvsi.com.vn/">TVSI</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.thumbvu.com/">thumbvu - Social Traffic Network</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.seriesflash.com/">Series Flash - Las Mejores Animaciones Flash Gratis en tu Ordenador.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.oxfordwesternmusic.com/">Home</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://wikimapia.org/">Wikimapia</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.interkonyv.hu/">Interkönyv</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.magicscroll.net/">MagicScroll.net: Read Your Favorite Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.smartinsights.com/strategy/digital-marketing-strategy/">Digital marketing strategy topic Digital marketing strategy > Smart Insights Digital Marketing</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.beslist.nl/">BESLIST.nl: zoeken, vergelijken, kopen</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.brasil247.com.br/">Brasil 247</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.internet4classrooms.com/links_grades_kindergarten_12/data_sources_web_project.htm">Data Resources Online for Project Based Teaching and Learning</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://cloudberrylab.com/default.aspx?page=cloudberry-backup">CloudBerry Lab - Online Backup powered by Amazon S3. Free for non-profit and education</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.ligahq.com.br/zero.php?tipo=1">HQ com frete grátis e bônus. X-Men, Homem-Aranha, Batman, manga, naruto, bleach.</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://chess.emrald.net/index.php">chess tactics server</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://olyapka.ru/2009/10/kak-pokupat-na-ebay/">Как покупать на eBay | Блог Оляпки</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://ushistoryeducatorblog.blogspot.com/">US History Teachers Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.westirondequoit.org/rogers/schaumbergweb/Oswego%20City%20School%20District%20Math%20Games.htm">Math Magician</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.reviraideias.com.br/">Revira Ideias :: produtos ecológicos e sustentáveis</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.outsideoutfitters.com/default.aspx">Outside Outfitters</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://foliohd.com/">Your Free and Easy Online Portfolio | FolioHD</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.just1word.com/">Just1Word: Search the Bible on Christian topics, people and stories.</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://store.apple.com/us/browse/home/shop_ipad/family/ipad">iPad - iPad WiFi - iPad WiFi + 3G - Apple Store (U.S.)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.etsy.com/shop/RogueTheory">handmade & functional by RogueTheory on Etsy</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.puromarketing.com/10/9811/peores-excusas-para-promocionar-empresa-internet.html">Las 10 peores excusas para no promocionar tu empresa en Internet - Puro Marketing</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.zbattle.net/">zbattle.net 2.0 :: Reloaded BETA 2</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.switchclimber.com/">SwitchClimber</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vipbox.tv/sports/motosport.html">Motorsports - Spin Those Wheels - Free Formula 1 & MotoGP Streaming Online - Formula 1 BBC Streaming</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://manas.tungare.name/software/isbn-to-bibtex/">ISBN to BibTeX Converter - Manas Tungare</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.treinaweb.com.br/cursos-online">Cursos Online - Relação dos Cursos Disponíveis | TreinaWeb Cursos</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.creative-weblogging.com/50226711/get_paid_to_blog.php">Creative Weblogging: Get Paid to Blog</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://blog.yourwebinconcert.com/uncategorized/12-social-media-listening-tools-essential-internet-marketing-best-practices-monitor-your-web">12+ Social Media ‘Listening Tools’ – Essential Internet Marketing Best Practices – Monitor Your Web | Your Web Best Practices</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="https://e-statements.bayareafastrak.org/statement.asp">Your Bay Area FasTrak Statement</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readbookonline.net/authors/">Author index [Novelist - short story writer - poet - playwright]</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.microsoft.com/athome/music/onlineradio.aspx?WT.rss_f=At%20Work%20RSS&WT.rss_a=Free%20music:%20Listen%20to%20the%20radio%20on%20your%20computer&WT.rss_ev=a">Windows Media Player: Listen to the radio on your computer</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.worldlingo.com/en/products_services/worldlingo_translator.html">Free Online Translator</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="https://pagseguro.uol.com.br/">Pag Seguro</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://hakim.se/experiments/html5/sinuous/01/">http://hakim.se/experiments/html5/sinuous/01/#</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://office.microsoft.com/en-us/welcome-to-the-2007-microsoft-office-system-FX101829962.aspx">Welcome to the 2007 Microsoft Office System - Microsoft Office</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://phpanywhere.net/">Online PHP Editor - PHPanywhere.net</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://websearch.about.com/od/usefulsite1/tp/free-fax-online.htm">Free Fax Online - The Top Five Sites for Online Faxing</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://watch0nline.info/">watch0nline - Home</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://publicliterature.org/">PublicLiterature.org</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.eyeonearth.eu/home.aspx">Eye on Earth</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://deangroom.posterous.com/note-taking-online-tools">Note Taking Online Tools - Design 4 Learning - Side Tracks</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://listentoyoutube.com/">ListenToYouTube.com: Youtube to MP3, get mp3 from youtube video, flv to mp3, extract audio from youtube, youtube mp3</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="https://www.chiliproject.org/">ChiliProject - Homepage - ChiliProject</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.plasticcardfactory.com/">Plastic Card Factory</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="https://www.erin.ne.jp/jp/">Erin ga Chosen</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://www.daopay.com/">daopay.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.avc.com/a_vc/2011/05/video-in-the-cloud.html">A VC: Video In The Cloud</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://vk.com/">VK</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://itunes.apple.com/us/app/simplenote/id289429962?mt=8">Simplenote for iPhone, iPod touch, and iPad on the iTunes App ...</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.vanlisten.de/">Hochzeitstisch, Hochzeitsliste - Van Listen</a>
</span>
</li>
<li>
<span style="background-color: lightgreen">
<a target="link" href="http://rubypdf.appspot.com/pdfdecrypt.html">PDF Password Remover Online|pdfdecrypt|Decrypt PDF Online</a>
</span>
</li>
</ol>
<h2>free</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://minutebio.com/blog/free-e-learning/">Free e-Learning | MinuteBio</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.dafont.com/bitmap.php?page=3">Da Font</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.devlounge.net/design/30-fonts-you-want-to-have">30 Fonts You Want to Have | Devlounge</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.brusheezy.com/Patterns">Photoshop Patterns – Free Photoshop Patterns at Brusheezy!</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="http://www.videosdahora.com.br/">Vídeos, engraçados,legais, incríveis, acidente</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.jteam.nl/2010/02/04/free-java-hosting-with-the-google-app-engine/">Free Java hosting with the Google App Engine « JTeam Blog / JTeam: Enterprise Java, Open Source, software solutions, Amsterdam</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://picresize.com/">Free Online Picture Resizer</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mytweeple.com/home.aspx?yourock=true">My Tweeple</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://openmaniak.com/tcpdump.php">TCPDUMP - The Easy Tutorial</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wizards.de/rawdrop/">RAWDrop - Frontend for dcraw</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://kids.niehs.nih.gov/music.htm#index">Sing Along Songs (Midis and Lyrics), NIEHS Kids' Pages</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thegridsystem.org/2009/templates/indesign-568x792-grid-system-12/">InDesign 568×792 Grid System (12) | The Grid System</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.podclub.ch/">www.podclub.ch - Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.oyonale.com/accueil.php?lang=en">Oyonale - 3D art and graphic experiments</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://enterzon.com/">EnterZon</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nycgovparks.org/sub_things_to_do/facilities/af_bike_maps.html">Greenway Maps & Publications : New York City Department of Parks & Recreation</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.totlol.com/">Totlol - Video for Toddlers, Infants, Preschoolers and Parents</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.chip.de/downloads/CDBurnerXP_13008371.html">CDBurnerXP - Download - CHIP Online</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://studyspanish.com/">Learn Spanish</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thaiegazine.com/egaz/index.php">magazine ดิจิตอล ออนไลน์ แมกกาซีน ศิลปะ ครีเอทีฟ ดีไซน์ กราฟฟิก เพลง หนัง ดารา หางาน :Thaiegazine.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.linuxtopia.org/online_books/index.html">Free On-line Linux Technical Books and Tutorials</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.myblogsite.com/">Free Blog from MyBlogSite.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.freetrafficsystem.com/">Free Traffic System - Increase Targeted Website Traffic with Free Unlimited One Way Links</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.exljbris.com/fertigo.html">Fertigo Pro - a free font from exljbris Font Foundry</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.instantshift.com/category/freebies/">Freebies | instantShift</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dynagen.org/">Dynagen The network configuration generator for Dynamips</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.greatmathsteachingideas.com/2011/01/16/the-10-best-maths-teaching-resource-websites/">The 10 Best Maths Teaching Resource Websites | Great Maths Teaching Ideas</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.stykz.net/index.php">Stykz • Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.contao.org/references.html">CMS (TYPOlight)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://webdesignledger.com/freebies/10-fresh-high-quality-free-fonts">10 Fresh High-Quality Free Fonts | Freebies</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sense-lang.org/typing/games/index.php?lang=EN">Sense-Lang Typing Games</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.textcompactor.com/">Text Compactor: Free Online Automatic Text Summarization Tool</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://maketecheasier.com/4-useful-visualizer-programs-to-monitor-your-macs-storage-space/2009/06/10">4 Useful Visualizer Programs to Monitor Your Mac’s Storage Space - Make Tech Easier</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://buzz.blogger.com/2010/06/blogger-template-designer-now-available.html">Blogger Buzz: Blogger Template Designer Now Available To Everyone</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.softschools.com/games/typing_games/">Typing Games : Free Typing Games For Kids</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.designer-daily.com/14-cool-free-fonts-11010?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+DailyDesignerNews+%28Daily+design+news%29&utm_content=Google+Reader">14 cool free fonts « Designer Daily</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.codershole.com/idump.php">CodersHole</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.biologybrowser.org/">BiologyBrowser.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://lifehacker.com/software/lifehacker-top-10/top-10-free-windows-file-wranglers-330037.php">Lifehacker Top 10: Top 10 Free Windows File Wranglers</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.antlermag.com/">antler magazine</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.learnboost.com/tour">Gradebook | LearnBoost</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.buildeazy.com/shed_1.html">How to build a storage shed</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://developer.appcelerator.com/get_started">Appcelerator Developer Center - Getting Started</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.elearnspace.org/Articles/open_source_part_1.htm">elearnspace. everything elearning.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.llsdc.org/Gen-Legal-Research/">General Legal Research Sites - Free and Commercial - Law Librarians' Society of Washington, D.C. - LLSDC</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.beezo.net/home.php">Beezo</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://majorgeeks.com/Windows_Installer_CleanUp_Utility_d4459.html">|MG| Windows Installer CleanUp Utility 7.2 Download</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://carsonified.com/toolkit/">Carsonified » Toolkit</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://vaxxine.com/mikwit/lessons/index.htm">Calligraphy Lessons On-Line</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.netplume.net/component/content/article/13/23-livre-photoshop-cs3">netPlume Rédaction pédagogique et internet - Livre Photoshop CS3 téléchargement libre</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.virtualpudding.com/web/arrival-free-child-theme-for-thematic/">Arrival – Free child theme for Thematic</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.webmasters-cavern.com/">Webmasters Cavern - Web Tools,Code Generators,Free Graphics, Webmaster Directory and more...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://tipnut.com/50-free-projects-for-baby/">Tipnut’s Picks: 41 Free Projects For Baby : TipNut.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wisdomcommons.org/">Wisdom Commons: Exploring, Elevating and Celebrating Our Shared Moral Core</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://internetgoschool.com/">Guo Juan's Internet Go School - Audio Go Lessons</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://openlibrary.org/subjects/accessible_book">Accessible book (Open Library)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://biblewebapp.com/study/">Romans 1:1 | BibleWebApp.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://uppix.net/">uppix.net - upload. share.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.socialbrite.org/2010/12/16/12-free-tools-to-measure-your-social-influence/">14 free tools to measure your social influence</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.timemarker.org/en/">timeMarker.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.growlforwindows.com/gfw/default.aspx">Growl for Windows</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mdch.state.mi.us/pha/osr/gendisx/search2.htm">Michigan Death Index</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nano-graph.com/sound/">III N A N O - S O U N D III</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cgtextures.com/index.php?pass=true">[CG Textures] - The worlds largest free texture site</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://xmoto.tuxfamily.org/">game physics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.immunet.com/main/index.html">Immunet</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.joshwoodward.com/music/">Creative Commons Music - Josh Woodward</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://web2project.net/">web2Project :: Your Life is a (web2)Project!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://code.google.com/javadevtools/index.html">Google Java Developer Tools - Google Code</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.findlaw.com/">legal answers</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://learnamericanenglishonline.com/">Learn American English Online</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seotxt.com/service/content_analyzer/">Бесплатный анализ сайта | Сервис оптимизации страниц на seotxt.com</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sweethome3d.eu/index.jsp">Sweet Home 3D</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://lavabit.com/apps/webmail/src/login.php">Lavabit</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://aslpro.com/">ASLPro.com Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.pdfforge.org/products/pdfcreator">pdfforge.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://hadleyweb.pwp.blueyonder.co.uk/CZP/News.htm">CombineZP News</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cheniere.org/misc/oulist.htm">The Tom Bearden Website</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.diem-project.org/">Diem Content Management Framework | Diem CMF CMS for symfony</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://chicago.craigslist.org/">craigslist: chicago classifieds for jobs, apartments, personals, for sale, services, community, and events</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.writewith.com/">writewith.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wildapricot.com/blogs/newsblog/archive/2010/07/08/32-free-online-tools-to-create-infographics.aspx">Wild Apricot Blog : 32 Free Online Tools to Create Infographics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://spyrestudios.com/freebies/snow-modern-ui-kit/">Snow – A Slick And Modern Web UI Kit | SpyreStudios</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vimeo.com/1084537">Big Buck Bunny</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hyperionics.com/hc/index.asp">HyperCam</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.cs.hmc.edu/~keller/jazz/improvisor/">Welcome to Impro-Visor</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.datawrangling.com/hidden-video-courses-in-math-science-and-engineering">Hidden Video Courses in Math, Science, and Engineering » Data Wrangling Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://getbuttonedup.com/tools/">Help Getting Organized | Get Organized with Organizational Tips from Buttoned Up | Free Printable Home Organization Forms | Buttoned Up</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.soundsnap.com/">Soundsnap.com: Find and Share Free Sound Effects and Loops</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://woopsdez.deviantart.com/art/iPhone-Gradation-Set-143036926">iPhone Gradation Set by ~woopsdez on deviantART</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://webfonts.fonts.com/en-US/Subscription/SelectSubscription">Select subscription - Fonts.com Web Fonts</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.kamikazemusic.com/quick-tips/html5-css3-starting-template/">HTML5 CSS3 starting template « Kamikazemusic.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://nfs.sparknotes.com/">No Fear Shakespeare - SparkNotes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.untiny.me/">Untiny</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.vpnreactor.com/">FREE VPN Service Provider: Online Privacy & Internet Security | VPNReactor.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.awooh.com/">Watch Movies Online for Free Without Downloading</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://leehansen.com/">Clip Art, Craft Graphics, Paper Crafts, Printables, Coloring Pages, Scrapbooking, Greeting Cards</a>
</span>
</li>
</ol>
<h2>howto</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.howtogeek.com/howto/windows-vista/add-run-as-administrator-to-any-file-type-in-windows-vista/">Add "Run as Administrator" to Any File Type in Windows 7 or Vista - How-To Geek</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://momthisishowtwitterworks.com/">mom, this is how twitter works. | not just for moms!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.macworld.com/article/158382/2011/03/ipad_power_user_tips.html">Ten tips for mastering the iPad | Tablets | iOS Central | Macworld</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://schoolofeverything.com/">School of Everything</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.911cd.net/forums//index.php?showtopic=21524">How to boot a bootable ISO from USB - The CD Forum</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://creativelittledaisy.typepad.com/creative_little_daisy/tutorials.html">creative little daisy: Tutorials</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://msdn.microsoft.com/en-us/vstudio/bb507746.aspx">How Do I? Videos for Visual Studio</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://lifehacker.com/#!5774324/how-to-get-more-from-your-home-theater-without-paying-a-dime">http://lifehacker.com/</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://raventools.com/blog/infographic-social-media-analytics/">Infographic: Social Media Analytics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wpbeginner.com/wp-themes/how-to-add-related-posts-with-a-thumbnail-without-using-plugins/">How to: Related Posts with Thumbnails in WordPress without Plugins</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.advancedspecialties.net/">Amateur Radio, Scanner Radios & CB Dealer - Advanced Specialties, Lodi NJ - ANLI, Yaesu.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://lifehacker.com/201072/technophilia-15-ways-to-get-more-out-of-pandora">Technophilia: 15 ways to get more out of Pandora</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.miracleas.com/BAARF/BAARF2.html">BAARF</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tutcast.com/">Adobe Photoshop Video Tutorials | High Quality, Professional Tutorials</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bonnieplants.com/">Bonnie Plants - Garden Plants for Your Vegetable Garden or ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://mccormick.cx/news/entries/how-to-write-beats.news">How to write drum beats - Chris McCormick</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.renaissancetailor.com/">Recreating 16th and 17th Century Clothing: The Renaissance Tailor</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://lambdadevp.blogspot.com/2010/11/creating-iphone-app-from-scratch.html">Dev-P: Creating an iPhone App &quot;From Scratch&quot;</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://chronicle.com/blogs/profhacker/creating-accessible-documents/33079">How to Create Accessible Documents - ProfHacker - The Chronicle of Higher Education</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ircbeginner.com/ircinfo/ircc-commands.html">#Beginner - IRC Commands, the Basics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.postfix.org/INSTALL.html">Postfix Installation From Source Code</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://articles.sitepoint.com/article/google-maps-api-jquery">Adding Markers to a Map Using the Google Maps API and jQuery</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.youtube.com/user/reporterscenter">YouTube - reporterscenter's Channel</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://drupal.org/node/495654">Panels 3: Creating a custom layout in your theme | drupal.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.adobe.com/accessibility/best_practices.html">Adobe - Accessibility: Best practices</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://stevenharman.net/blog/archive/2008/12/13/vnc-to-a-headless-ubuntu-box.aspx">VNC to a Headless Ubuntu Box</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.catonmat.net/blog/perls-special-variable-cheat-sheet/">Perl's Special Variable Cheat Sheet</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blogoscoped.com/archive/2008-01-23-n82.html">Writing a Book in Google Docs</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.briansolis.com/2010/04/the-future-of-marketing-starts-with-publishing-part-2/">The Future of Marketing Starts with Publishing Part 2</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mvps.org/dmcritchie/excel/sheets.htm">Worksheets in VBA Coding and in Worksheet Formulas</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.geekzone.co.nz/content.asp?contentid=903">How to configure your desktop/laptop to use the Bluetooth headset</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://simple.procoding.net/2008/03/21/how-to-access-iframe-in-jquery/">How to access iframe in jQuery</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.productivity501.com/">Productivity501</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.utahmountainbiking.com/goodies/TruckbedBikeRack.htm">Make your own Bike Rack</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://help.ubuntu.com/community/UEC">UEC - Community Ubuntu Documentation</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.deke.com/">dekeOnline</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cs.gmu.edu/~sean/lisp/LispTutorial.html">Learning Lisp Fast</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.popularmechanics.com/home/skills/4281414">100 Skills Every Man Should Know: 2008's Ultimate DIY List - Popular Mechanics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.howtoforge.com/hp_systems_insight_manager_centos">Installing HP Systems Insight Manager On CentOS | HowtoForge - Linux Howtos and Tutorials</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://kindleformatting.com/index.php">Kindle Formatting</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://solve99problems.tumblr.com/">solve99problems</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://reverb.madstatic.com/blog/2006/04/01/make-a-photo-light-box-light-tent-cheap/">Make A Photo Light Box / Light Tent Cheap at Reverb</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://shermanlive.com/2009/10/19/how-to-set-up-ustream-for-live-video-broadcasting-nms008/">How To Set Up Ustream For Live Video Broadcasting | Sherman Hu | ShermanLive.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.insight-it.ru/masshtabiruemost/arkhitektura-twitter-dva-goda-spustya/">Архитектура Twitter. Два года спустя | Insight IT</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://abduzeedo.com/creating-crazy-cool-logo">Creating a crazy cool logo | Abduzeedo | Graphic Design Inspiration and Photoshop Tutorials</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://thinkabdul.com/2007/08/21/tutorial-howto-share-3ggprsumts-internet-connection-from-windows-mobile-6-to-windows-vista-or-mac-osx-using-bluetooth-pan-profile/">  Tutorial: HowTo Share 3G/GPRS/UMTS Internet Connection from Windows Mobile 6 to Windows Vista or Mac OSX using Bluetooth PAN Profile by Tech[dot]Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://whatscookingamerica.net/Vegetables/driedbeantip.htm">Dried Beans, How To Cook Dried Beans, Dried Bean Guide, How To Soak Dried Beans</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.instructables.com/id/Earbud-cord-wrapper-in-5-minutes-or-less!/">Earbud cord wrapper in 5 minutes or less!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://designinstruct.com/drawing-illustration/draw-a-3d-umbrella-with-photoshop/">Draw a 3D Umbrella with Photoshop</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.thoughtpick.com/2010/10/how-to-backup-your-facebook-account.html">HOW TO: Backup Your Facebook Account</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.dg28.com/index.htm">dg28.com - photographer education</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.catb.org/~esr/faqs/smart-questions.html">How To Ask Questions The Smart Way</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://manas.tungare.name/blog/howto-setup-webdav-on-mac-os-x/">HOWTO Setup WebDAV on Mac OS X - Manas Tungare</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.costumeclassroom.com/">Costume Classroom</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.webteacher.com/javascript/">Java script tutorial for the total non-programmer</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="ftp://ftp.fernuni-hagen.de/pub/pdf/urz-broschueren/broschueren/a0260003.pdf">a0260003.pdf (application/pdf-Objekt)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://washort.twistedmatrix.com/2010/11/unicode-in-python-and-how-to-prevent-it.html">Unicode in Python, and how to prevent it</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hack7mc.com/2009/02/mkvs-for-minimalists-on-windows-7.html">MKVs for Minimalists on Windows 7</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.phpeveryday.com/articles/CodeIgniter-Introduction-to-CodeIgniter-Framework-P146.html">CodeIgniter: Introduction to CodeIgniter Framework Step By Step ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://oggettoweb.com/blog/unit-testing-in-magento-using-phpunit-and-xdebug/">The Most Comprehensive Guide to Unit Testing in Magento Using PHPUnit and Xdebug | Oggetto Web</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.webdeveloperjuice.com/2010/08/21/30-search-engine-optimization-techniques-you-cannot-miss/">30+ Search Engine Optimization Techniques You Cannot Miss</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://learntocrochet.lionbrand.com/">Learn to Crochet: Lion Brand Yarn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.stevenyork.com/tutorial/pure_css_opacity_and_how_to_have_opaque_children">Pure CSS opacity and how to have opaque children, css, xhtml, Steven York.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.osxfacile.com/">Mac OS X facile</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cs.tut.fi/~jkorpela/fileurl.html">File URLs</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.voip-info.org/wiki/index.php?page=Asterisk+functions">Asterisk functions - voip-info.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bitrebels.com/geek/20-tips-to-look-younger-today/">20 Tips to Look Younger Today « Bit Rebels</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://stackoverflow.com/questions/538996/constants-in-objective-c">cocoa - Constants in Objective C - Stack Overflow</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://photonotes.org/articles/eos-flash/index.html">Flash Photography with Canon EOS Cameras - Part I.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://jarv.org/pwrmon.shtml">jarv.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://learnbythedrop.com/">Learn By The Drop | A place to learn Drupal.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.xaprb.com/blog/2009/08/23/how-to-find-per-process-io-statistics-on-linux/">How to find per-process I/O statistics on Linux at Xaprb</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tuaw.com/2008/10/29/6-easy-steps-to-migrate-your-mac-using-time-machine/">6 easy steps to migrate your Mac using Time Machine | TUAW - The Unofficial Apple Weblog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.userfocus.co.uk/articles/websurveys.html">Web survey design step-by-step</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.satya-weblog.com/2010/04/how-to-delete-cached-file-on-client-side.html">How to Delete Cached File on Client Side ?</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://research.mosuma.com/faq/howto/svn_branch_merge">Branch & Merge using svn — Research</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://wiki.eclipse.org/FAQ_How_do_I_add_activities_to_my_plug-in%3F">FAQ How do I add activities to my plug-in? - Eclipsepedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://davidwalsh.name/php-calendar">CSS PHP Calendar</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://everydayrails.com/2011/01/19/learning-ruby-rails.html">Learning Ruby and Rails</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.stringpage.com/index.html">Phiala's String Page</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://mato.blogsome.com/2006/10/21/servirdor-streaming-de-mp3-en-ubuntu/">Pareto :: Servidor streaming de mp3 en Ubuntu :: October :: 2006</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blogs.forbes.com/susanadams/2011/03/24/how-to-write-a-cover-letter/">How To Write A Cover Letter - Susan Adams - Getting Ahead ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.taloushallintoliitto.fi/tilitoimistot/kirjanpidon_abc/">Kirjanpidon ABC - Taloushallintoliitto</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://qmail.jms1.net/scripts/qfixq.shtml">qfixq</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.rememberthemilk.com/2009/09/introducing-smart-add-a-smarter-way-to-add-your-tasks/">Remember The Milk - Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://help.ubuntu.com/community/LiveCDCustomization">LiveCDCustomization - Community Ubuntu Documentation</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.brennan.id.au/20-Shared_Address_Book_LDAP.html">Linux Home Server HOWTO - Shared Address Book (LDAP)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.homenethelp.com/">DIY home networking guides and tutorials</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.debianuniverse.com/">Debian Universe - installing, managing and running Debian Gnu/Linux</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ghidinelli.com/2009/07/16/finding-memory-leaks-coldfusion-jvm">Finding memory leaks in your ColdFusion JVM » ghidinelli.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://searchenginewatch.com/3640262">Google Analytics, Conversion Tracking & Single Segment Reporting Power - Search Engine Watch (SEW)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blogs.gnome.org/lharris/2008/07/20/code-completion-with-vim-7/">Code Completion with VIM 7 « Les Harris</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wikihow.com/Avoid-Colloquial-(Informal)-Writing">How to Avoid Colloquial (Informal) Writing - WikiHow</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://code.google.com/p/google-sites-liberation/">google-sites-liberation - Project Hosting on Google Code</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://samanathon.com/how-to-install-microsoft-office-2007-in-ubuntu-9-04/">How To Install Microsoft Office 2007 In Ubuntu 9.04 ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.faqs.org/docs/bashman/bashref.html#SEC_Top">Bash Reference Manual: Bash Reference Manual</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikibooks.org/wiki/Programming:Python">Programming:Python - Wikibooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.marthastewart.com/article/simple-baby-quilt?backto=true&backtourl=/photogallery/sewing-projects-for-kids#slide_6">Simple Baby Quilt - Martha Stewart Crafts</a>
</span>
</li>
</ol>
<h2>books</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.amazon.com/Simulacra-Simulation-Body-Theory-Materialism/dp/0472065211">Amazon.com: Simulacra and Simulation (The Body, In Theory: Histories of Cultural Materialism) (9780472065219): Jean Baudrillard, Sheila Faria Glaser: Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.indiebound.org/">Be a Part of the Story | IndieBound</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.duden.de/">(DE-DE) Duden online - duden.de</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fcps.edu/dis/readlist/78.htm">Summer Reading Lists  - Rising 7th and 8th graders</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.digitizd.com/2011/02/22/the-feeling-of-reading-a-book/">The Feeling of Reading a Book | Digitizd</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.amazon.com/Robert-Frank-Americans/dp/3931141802">Amazon.com: Robert Frank: The Americans (9783931141806): Robert Frank, Jack Kerouac: Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://mashable.com/2010/12/09/evernote-by-the-numbers-stats/">Evernote By the Numbers [STATS]</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikibooks.org/wiki/Italian">Italian - Wikibooks, collection of open-content textbooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.contabilidad.tk/Libro-introduccion-contabilidad.htm">LIBRO DIGITAL: Introducción a la Contabilidad</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.teneues.com/shop-us/index.php">teNeues Publishing Group</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.insidehighered.com/news/2011/03/17/new_book_on_history_of_information_overload">News: 'Too Much to Know' - Inside Higher Ed</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://atmac.org/bookshare-ipad-iphone-ipod-touch">Putting Bookshare.org Books On The iPad</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mode-et-internet.com/">Mode & Internet : Le marketing épinglé de Bertrand Jouvenot</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://legacy.www.nypl.org/research/chss/events/booklist.html">NYPL, Books of the Century</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://ec.europa.eu/education/lifelong-learning-policy/doc2082_en.htm">Measuring Creativity_European Commission - Education & Training - lifelong learning policy</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/The_Golden_Bough">The Golden Bough - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://thesheckspot.blogspot.com/">The Sheck Spot</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.amazon.com/How-Cook-Everything-Vegetarian-Meatless/dp/0764524836">Amazon.com: How to Cook Everything Vegetarian: Simple Meatless Recipes for Great Food (9780764524837): Mark Bittman, Alan Witschonke: Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.silverlightshow.net/Books.aspx">SilverlightShow: Silverlight Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.manybooks.net/language.php?code=fr">manybooks.net - Languages: French</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://ebooksgratis.com.br/tag/audiobook/">Audiobook | Blog E-books Grátis - Tudo sobre literatura, download de livros grátis, revistas, quadrinhos e muito mais!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://wiki.mobileread.com/wiki/E-book_stores">MobileRead Wiki - E-book stores</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://programming-android.labs.oreilly.com/index.html">Programming Android</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://litopia.com/">Litopia Writers' Colony</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://books.google.nl/">Google Boeken</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://diecichilidiperle.blogspot.com/">Dieci chili di perle</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://oreilly.com/catalog/9780596154141/">Programming Interactivity - O'Reilly Media</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mixup.com.mx/">Mixup Music Store</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.makeuseof.com/tag/easy-listening-pleasures-10-websites-free-audio-book-downloads/">10 Websites For Free Audio Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://oreilly.com/catalog/9780596807740/">Building Wireless Sensor Networks - O'Reilly Media</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://radiusbooks.org/">Radius Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.onlinecomputerbooks.com/free-information-technology-books.php">onlinecomputerbooks | Lista com vários livros gratuitos</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.noflyingnotights.com/">no flying, no tights -- graphic novel reviews</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://librivox.org/newcatalog/genres.php">LibriVox: Catalog Pages</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://zacharyburt.com/2010/11/what-makes-two-people-click/">What makes people click with each other? — ZacharyBurt.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.angusrobertson.com.au/">Buy books online from Australia's leading online book store | Angus & Robertson</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readingforlife.org.uk/">Reading for Life - Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/Thursday_Next">Thursday Next - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.waterrowbooks.com/">Water Row Books - Selling and Publishing Original Beat and Underground Literature Since 1978</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hkreaders.com/">序言書室</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.maps.org/gateway/">Through the Gateway of the Heart - Ralph Metzner - Table of Contents</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.peep-hole.org/">Peep-Hole</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://modernistcuisine.com/about-modernist-cuisine/table-of-contents/">Table of Contents | Modernist Cuisine: The Art and Science of Cooking</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.litcharts.com/">LitCharts.com | LitCharts Study Guides | The faster, downloadable alternative to SparkNotes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://press.princeton.edu/books/maor/">Maor, E.: Trigonometric Delights.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.artistsbooksonline.org/">Artists' Books Online</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://principiadiscordia.com/">Principia Discordia | the book of Chaos, Discord and ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gallica.bnf.fr/">Gallica, bibliothèque numérique de la Bibliothèque nationale de France</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.controllingparents.com/">If You Had Controlling Parents</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.comicer.com/stronghorse/software/index.htm">老马的原创空间-原创软件</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.amazon.com/Someday-This-Pain-Will-Useful/dp/0374309892">Amazon.com: Someday This Pain Will Be Useful to You: Peter Cameron: Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.perma-bound.com/library/">Perma-Bound School Library - Perma-Bound Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vijaymukhi.com/documents/books/">Index of /documents/books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://shop.ebrary.com/home.action">ebrary: Library Info</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://scrap.oldbookillustrations.com/">OBI Scrapbook Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.rifters.com/real/Behemoth.htm">behemoth</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.romapublications.org/main.html">Roma Publications</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tnr.com/book">The Book | The New Republic</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://peggyorenstein.com/resources.html">Peggy Orenstein | Resources</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bankstreet.edu/childrenslibrary/booklists.html">Bank Street Library: Children's Book Lists</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://nexus.realtimepublishers.com/">Realtime Nexus Digital Library - Free eBooks and publications for information technology professionals and executives</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.manning.com/skeet2/">Manning: C# in Depth, Second Edition</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.jennycrusie.com/">Bestselling Author Jennifer Cruise's Home Page</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.insidehighered.com/news/2009/11/06/library">News: Bookless Libraries? - Inside Higher Ed</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.1morechapter.com/">1morechapter.com —</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://thomasallenonline.com/">http://thomasallenonline.com/</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wetasphalt.com/?q=content/how-write-book-three-days-lessons-michael-moorcock">How to Write a Book in Three Days: Lessons from Michael Moorcock | Wet Asphalt</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.maa.org/EbusPPRO/Bookstore/tabid/37/Default.aspx">Personify eBusiness > Bookstore</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.eurodroid.com/2010/02/five-of-the-best-android-development-books/">Five of the best Android development books » EuroDroid</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.amazon.com/gp/product/1933988657?ie=UTF8&tag=httpwwwrailst-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=1933988657">Amazon.com: The Well-Grounded Rubyist (9781933988658): David A. Black: Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bookworks.org.uk/asp/resources.asp?sub=facts">Book Works - Resources - Fact-sheets</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://metaoptimize.com/qa/questions/186/good-freely-available-textbooks-on-machine-learning">Good Freely Available Textbooks on Machine Learning - MetaOptimize Q+A</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/The_Man_Who_Folded_Himself">The Man Who Folded Himself - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://bibliotecas.csic.es/">Red de Bibliotecas del CSIC - Página principal</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.salon.com/life/feature/2011/05/15/trazzler_slide_show_beautiful_bookstores">The world's most inspiring bookstores - Travel content by Trazzler - Salon.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tianyabook.com/">天涯在线书库</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://tldp.org/LDP/tlk/tlk-toc.html">The Linux Kernel: Table of Contents</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.webbasedprogramming.com/">Web Based Programming Tutorials - CGI, Java, MySQL, Perl, HTML, Oracle, VBScript, Visual Basic, Java Applets and lots more!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.reddotawards.com/">Red Dot Book Awards 2010-2011</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.philobiblon.com/">Welcome to the Book Arts Web</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://hs2.me/hs2book">Человек Разумный 2.0 | Homo Sapiens 2.0</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readingtimes.com.tw/ReadingTimes/default.aspx">時報悅讀網：時報出版官方網站 (?)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://thehungergames.wikia.com/wiki/The_Hunger_Games_Wiki">The Hunger Games Wiki</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.law.ou.edu/hist/">A Chronology of US Historical Documents</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wiez.com.pl/islam/">Leksykon dla dziennikarzy - "Nie bój się islamu"</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.amazon.com/Social-Transformation-American-Medicine-profession/dp/0465079350">Amazon.com: The Social Transformation of American Medicine: The rise of a sovereign profession and the making of a vast industry (9780465079353): Paul Starr: Books</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.booksshouldbefree.com/genre/Non-fiction">Free Audio Books - Non-fiction - Download mp3 and iPod format today!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.guardian.co.uk/science/2008/oct/25/richard-dawkins-religion-science-books">Interview: Richard Dawkins - 'People say I'm strident' | Science | The ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://saracwynar.com/">SARA CWYNAR</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://leiterreports.typepad.com/blog/2009/03/so-who-is-the-most-important-philosopher-of-the-past-200-years.html">Leiter Reports: A Philosophy Blog: So who *is* the most important philosopher of the past 200 years?</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.isbn.nu/">ISBN.nu</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://un2sg4.unige.ch/athena/html/athome.html">ATHENA - Pierre Perroud</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hanselman.com/blog/Spring2011FictionReadingListYoungAdultEBooksWillSaveScienceFiction.aspx?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+ScottHanselman+%28Scott+Hanselman+-+ComputerZen.com%29">Spring 2011 Fiction Reading List - Young Adult eBooks Will Save Science Fiction - Scott Hanselman</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tiskkym.com/blog/02publications/">TAISUKE KOYAMA Info: Publications Archive</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.npr.org/templates/story/story.php?storyId=16435529">NPR : Reading Study Shows Remarkable Decline in U.S.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://pbskids.org/lions/cornerstones/click/story/hypertext/">Click, Clack, Moo</a>
</span>
</li>
</ol>
<h2>semanticweb</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://marc-must-die.info/index.php/Main_Page">Main Page - MARC must die!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.guardian.co.uk/media/pda/2011/apr/06/bbc-yves-raimond">BBC Builders: Yves Raimond on the BBC's interlinked, semantic web of the future | Media | guardian.co.uk</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dallemang.typepad.com/my_weblog/2008/08/rdf-as-self-describing-data.html">S is for Semantics: RDF as self-describing data</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.franz.com/agraph/gruff/">Gruff: A Grapher-Based Triple-Store Browser for AllegroGraph</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://openresearch.org/wiki/Main_Page">OpenResearch.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.knowledgesearch.org/lsi/lsa_definition.htm">Latent Semantic Indexing</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readwriteweb.com/archives/the_state_of_linked_data_in_2010.php">The State of Linked Data in 2010</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.kanzaki.com/works/2006/misc/0308turtle.html">Javascript RDF/Turtle Parser</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blogs.nature.com/jhendler/2009/06/16/what-is-the-semantic-web-really-all-about">What is the Semantic Web really all about? - Web Science - the World of the World Wide Web Blog | Nature Publishing Group</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mediawiki.org/wiki/Extension:RDFIO">Extension:RDFIO - MediaWiki</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.twine.com/">Twine - Organize, Share, Discover Information Around Your Interests | Twine</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sindice.com/main/about">About Sindice</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.plantontology.org/">Plant Ontology Consortium web site at http://www.plantontology.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://forge.morfeo-project.org/wiki_en/index.php/Units_of_measurement_ontology">Measurement Units Ontology - Morfeo Wiki</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://drupal.org/project/sparql_ep">RDF SPARQL Endpoint | drupal.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://ismir2009.dbtune.org/taxonomy/term/5">SPARQL Endpoints | Music and the Web of Linked Data</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www4.wiwiss.fu-berlin.de/bizer/pub/LinkedDataTutorial/">How to publish Linked Data on the Web</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thoughtark.com/thoughtark/public/">ThoughtArk</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://wiki.cetis.ac.uk/images/1/1a/The_Semantic_Web.pdf">wiki.cetis.ac.uk/images/1/1a/The_Semantic_Web.pdf</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ontologyportal.org/">The Suggested Upper Merged Ontology (SUMO)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.purlz.org/">Persistent URLs</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sourceforge.net/projects/semanticscuttle">SemanticScuttle | Download SemanticScuttle software for free at SourceForge.net</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sheeeer.wordpress.com/2011/05/05/a-shot-at-rdf-schema-discovery/">A shot at RDF schema discovery « Fadi Maali's Bite of the Web</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seoconsultants.com/meta-tags/dublin/">DC Dublin Core META Tags: DCMI Dublin Core Metadata Initiative</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www-sop.inria.fr/edelweiss/">Edelweiss Research Team - Equipe de recherche Edelweiss - INRIA Sophia Antipolis</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ontopia.net/omnigator/models/index.jsp">[Omnigator] Welcome Page</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://willdaniels.co.uk/reference/rdf-vocabulary">RDF Vocabularies</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.musicontology.com/">Music Ontology Specification</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://eprints.ecs.soton.ac.uk/21587/">Why Linked Data is Not Enough for Scientists - ECS EPrints Repository</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://csc.media.mit.edu/conceptnet">ConceptNet | Common Sense Computing Initiative</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://data-gov.tw.rpi.edu/ws/sparqlprobe.php">data-gov.tw.rpi.edu/ws/sparqlprobe.php</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.inkzee.com/">Inkzee - more in less</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www4.wiwiss.fu-berlin.de/lodcloud/state/">State of the LOD Cloud</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://tech.puredanger.com/2010/06/24/using-clojure-and-clj-plaza-to-play-with-rdf-data/">Using Clojure and clj-plaza to play with RDF data : Pure Danger Tech</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://beckr.org/marbles">Marbles</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://linkedlifedata.com/">Linked Life Data</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://owlapi.sourceforge.net/javadoc/index.html">Overview (The OWL API)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bbc.co.uk/blogs/bbcinternet/2010/07/the_world_cup_and_a_call_to_ac.html">BBC - BBC Internet Blog: The World Cup and a call to action around Linked Data</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dev.iptc.org/rNews">- rNews</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.datagraph.org/2010/04/transmuting-ntriples">RDF for Intrepid Unix Hackers: Transmuting N-Triples - The Datagraph Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readwriteweb.com/archives/green_goose_wows_the_crowd_raises_100k_on_launch_c.php">Green Goose Wows the Crowd & Raises $100K On Launch Conference Stage</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://rubhub.com/">rubhub.com - Social Search</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://code.google.com/p/semanticvectors/">semanticvectors - Google Codediv class=entry-title-go-todiv</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.chiefmartec.com/2010/01/7-business-models-for-linked-data.html">7 business models for linked data</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.slideshare.net/scorlosquet/how-to-build-linked-data-sites-with-drupal-7-and-rdfa">How to Build Linked Data Sites with Drupal 7 and RDFa</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://smartideabox.com/blog/silk-get-answers-to-complexe-questions-in-minutes-with-breakthrough-accessible-semantic-technology/">Silk – Get Answers to Complexe Questions in Minutes with Breakthrough Accessible Semantic Technology</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://code.google.com/p/linqtordf/">LinqToRdf</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cubist-project.eu/index.php?id=443">Cubist: General Information</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sig.ma/">Sig.ma EE- Semantic Information Mashup Enterprise Edition</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://semanticweb.org/wiki/VoiD">VoiD - semanticweb.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.openlinksw.com/blog/~kidehen/">Kingsley Idehen's Blog Data Space</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://platform.newscred.com/">NewsCred Platform - Intelligent Content Solutions</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://mozillalabs.com/blog/2008/08/introducing-ubiquity/">Ubiquity - Mozilla Labs</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blogs.talis.com/research/2011/04/14/follow-your-nose-across-the-globe/">Talis Research » Blog Archive » ‘Follow Your Nose’ Across the Globe</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gospels.cognition.com/">Gospels.Cognition.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://clarkparsia.com/pellet/">Pellet: OWL 2 Reasoner for Java</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.w3.org/TR/rdf-primer/">RDF Primer</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.christian-faure.net/2008/11/02/quest-ce-quune-uri-dereferencable/">Qu’est-ce qu’une « URI déréférençable » ?</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://joshuafost.com/glassbeadgame/gbg.html">Toward the Glass Bead Game - a rhetorical invention</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://pt.wikipedia.org/wiki/Ontologia_(ci%C3%AAncia_da_computa%C3%A7%C3%A3o)">Ontologia (ciência da computação) – Wikipédia, a enciclopédia livre</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://html5doctor.com/the-hgroup-element/">The hgroup element | HTML5 Doctor</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.alchemyapi.com/products/">AlchemyAPI - Products</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ibm.com/developerworks/web/library/wa-rdf/index.html">The Semantic Web, Linked Data and Drupal, Part 1: Expose your ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.the-haystack.com/2010/12/17/death-to-web-services-long-live-web-services/">Death to web services. Long live web services!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://id.loc.gov/authorities">Authorities & Vocabularies (Library of Congress)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://virtuoso.openlinksw.com/whitepapers/rdf%20linked%20data%20dotNET%20LINQ.html">Exploiting the RDF-based Linked Data Web using .NET via LINQ</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://adactio.com/journal/1292/">Adactio: Journal—Further reading on the nanotechnology of the semantic web</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sioc-project.org/ontology">SIOC Ontology | sioc-project.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.zdnet.com/blog/hinchcliffe/the-future-of-enterprise-data-in-a-radically-open-and-web-based-world/650">The future of enterprise data in a radically open and Web-based world | ZDNet</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.google.com/support/webmasters/bin/answer.py?hl=en&answer=99170">Rich snippets (microdata, microformats, and RDFa) - Webmaster Tools Help</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.kiwitobes.com/">kiwitobes.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www4.wiwiss.fu-berlin.de/bizer/d2r-server/index.html">D2R Server – Publishing Relational Databases on the Semantic Web</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/User_experience">User experience - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.w3.org/TR/rdf-concepts/">Resource Description Framework (RDF): Concepts and Abstract Syntax</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://iswc2011.semanticweb.org/">The 10th International Semantic Web Conference: Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://singhal.info/ieee2001.pdf">ieee2001.pdf (application/pdf Object)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dannyayers.com/">Danny Ayers : Raw Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://code.google.com/apis/socialgraph/docs/otherme.html">Social Graph API's "otherme" method - Social Graph API - Google Code</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.sindice.com/2009/07/22/sigma-live-views-on-the-web-of-data/">Sig.ma – Live views on the Web of Data - Sindice Blog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://owl.cs.manchester.ac.uk/tutorials/protegeowltutorial/">Protege OWL tutorial at Manchester (School of Computer Science – The University of Manchester)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://pingthesemanticweb.com/stats/namespaces.php">Ping the Semantic Web.com - Share your RDF documents with the World!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/Natural_language_processing_toolkits">List of natural language processing toolkits - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://alatechsource.metapress.com/content/g212v1783607/?p=b4700bc9fec34b12a3f42a94a9fd9d4f&pi=0">ALA TechSource - Journal Issue</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://xwn.hlt.utdallas.edu/index.html">eXtended WordNet</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ifla.org/files/hq/papers/ifla76/149-hannemann-en.pdf">Linked Data for Libraries</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.zumodrive.com/about">ZumoDrive - About us</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.iskouk.org/conf2011/index.htm">ISKO UK Conference 2011</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://html5doctor.com/microdata/">Extending HTML5 — Microdata | HTML5 Doctor</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hipertext.net/web/pag260.htm">Los tesauros y las ontologías en la Biblioteconomía y la ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dbpedia.org/About">wiki.dbpedia.org : About</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readwriteweb.com/archives/3_sensor_data_platforms_to_watch.php">3 Sensor Data Platforms to Watch</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sig.biostr.washington.edu/projects/fm/AboutFM.html">Foundational Model of Anatomy ontology - About</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mkbergman.com/192/free-rdf-and-owl-editors-for-eclipse-developers/">Free RDF and OWL Editors for Eclipse Developers » AI3:::Adaptive Information</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dig.csail.mit.edu/breadcrumbs/node/149">An Introduction and a JavaScript RDF/XML Parser | Decentralized Information Group (DIG) Breadcrumbs</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.youtube.com/watch?v=bsNcjya56v8">YouTube - Evolution Web 1.0, Web 2.0 to Web 3.0</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://rundom.com/semantic/">Semantic Weblog</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dynamicorange.com/">A Low-Frequency Thunk by Rob Styles. | I Really Don’t Know</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.educause.edu/EDUCAUSE+Quarterly/EDUCAUSEQuarterlyMagazineVolum/TheSemanticWebinEducation/163437">The Semantic Web in Education (EDUCAUSE Quarterly) | EDUCAUSE</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dbpedia.org/snorql/">SPARQL Explorer for http://dbpedia.org/sparql</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readwriteweb.com/archives/10_ideas_for_web_of_data_apps.php">10 Ideas For Web of Data Apps</a>
</span>
</li>
</ol>
<h2>game</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://freeciv.wikia.com/wiki/The_Art_of_Freeciv_2.1">The Art of Freeciv 2.1 - The Freeciv Wiki - Mods, coding, art, and more</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gotoandplay.it/">gotoAndPlay(): Flash games, tutorials and game development</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://teacher.scholastic.com/activities/bhistory/underground_railroad/plantation.htm">Life on the Plantation | Underground Railroad Student ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gamepeople.co.uk/board_board_plasticanimalchess.htm">Plastic Animal Chess Rules Board Games Review | Board Gamer</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gamasutra.com/view/news/33820/Opinion_Dealing_With_Designer_Input_Latency.php">Gamasutra - News - Opinion: Dealing With Designer Input Latency</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gamedevmap.com/index.php?tool=location&query=San%20Francisco">gamedevmap</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://game.worldoftanks.com/registration/">New User Registration :: World of Tanks: MMO Tank Action Game</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.studiohangloose.it/en/blog/436/augmented-reality/">Studio Hangloose » Augmented reality</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gamesareevil.com/wp-content/uploads/2010/03/History-of-Video-Game-Development-Studios-Flow-Chart-2.jpg">History-of-Video-Game-Development-Studios-Flow-Chart-2.jpg (JPEG Image, 2878x5142 pixels)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.insidemacgames.com/reviews/">Inside Mac Games: Reviews</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://clickjogos.uol.com.br/Jogos-online/Acao-e-Aventura/You-Draw/">Click Jogos - You Draw</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.lostlabyrinth.com/">Lost Labyrinth ~ The best Roguelike on the Net</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.harcourtschool.com/activity/mmath/mmath_dr_gee.html">Mighty Math Web Activities</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.funny-city.com/1845/">Spin the black circle</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ninjasenki.com/">Ninja Senki</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.newgrounds.com/portal/view/470460">Doom 1 Flash</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://funschool.kaboose.com/formula-fusion/games/game_dr_brains_robot.html">Funschool - Formula Fusion - Dr. Brain's Robot</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://shootmanyrobots.com/">Shoot Many Robots</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://m.kongregate.com/">M.kongregate.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.kongregate.com/games/IcyLime/multitask-2">Play Multitask 2, a free online game on Kongregate</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.dcuniverseonline.com/">DC Universe Online - Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wildpockets.com/">Wild Pockets |</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dougx.net/plunder/index.php#code">GALACTIC PLUNDER</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://news.bbc.co.uk/2/hi/science/nature/7533909.stm">Animated guide: Hurricanes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mirsoft.info/index.php">Musique de vieux jeux</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.storyabout.net/typedrawing/">TYPEDRAWiNG | created by storyabout.net</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gas13.ru/v3/tutorials/isometric_pixelart_tutorial_setup_photoshop_for_pixelart.php">Photoshop tutorials and Pixelart tutorials, smiles and pixelart | Gas13.ru</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://kanobu.ru/">Канобу – игровой портал | Компьютерные игры, фильмы, книги, сообщества, игровые события | Прохождения игр, обзоры | Скачать патчи и трейнеры | Канобувости - новости игр, рецензии, превью, видео, скриншоты</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gamekings.tv/">Gamekings: Elke dag nieuwe video's</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://lunchtimers.com/">Lunchtimers - Lunchtimers.com - Multi user Online Flash Games: Just Letters, The Scratchpad and more</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fatbraintoys.com/toy_companies/thinkfun/chocolate_fix_flash_game.cfm">Chocolate Fix Interactive Online Game</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thegamesjournal.com/articles/WhatMakesaGame.shtml">What Makes a Game Good?</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.makeyourflashgame.com/tag/pbengine">makeyourflashgame.com - The Game Creation Community - Where creative people can create flash games together</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sternpinball.com/">STERN Pinball</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wingood.com/flagselect.asp">Nautical Signal Flag Translator</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.purposegames.com/games">Test Your Knowledge With Trivia Games</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.namesuppressed.com/kenny/">Kenny Translator - translate text into Kennyspeak</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.addictinggames.com/D78AQSAKQLQWI9/5949.swf">5949.swf (application/x-shockwave-flash Object)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vg247.com/">VG247</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wiiplayable.com/">Wii Flash Games - WiiPlayable</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mobygames.com/">The Authoritative Video Game Database - Reviews and Information - MobyGames</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.leylijnen.com/">Index</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.e-games.tech.purdue.edu/GameDevProcess.asp">Mobile 3D Presentation at TLT</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://buttonbeats.com/">Button Beats Make Music online. Play the Virtual Piano.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://freemusicarchive.org/genre/Chiptune/">Free Music Archive: Chiptune</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://playgunman.com/">Gunman - The first iPhone game to put you in the crossfire.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bbc.co.uk/schools/magickey/adventures/fraser_game.shtml">- Fraser the Eraser Game</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://bartoparcade.katorlegaz.com/">Bartop Arcade - Kator Legaz</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sheppardsoftware.com/content/animals/kidscorner/classification/kc_class_again.htm">http://www.sheppardsoftware.com/content/animals/kidscorner/classification/kc_class_again.htm</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tigweb.org/tiged/projects/ayiti/">TakingITGlobal - TIGed - Ayiti</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://webgame.pchome.com.tw/">PChome Online 網路家庭 - 小遊戲</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://arsludi.lamemage.com/index.php/94/west-marches-running-your-own/">ars ludi » West Marches: Running Your Own</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.playr.org/games">playR - Free old school flash gaming action online!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.learninggamesforkids.com/animal_and_nature_games.html">Animal and Nature Learning Games For Kids | Learning Games For Kids</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://insideastarfilledsky.net/">Inside a Star-filled Sky</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.steampowered.com/nvidia/">Portal: First Slice is free for all NVIDIA Gamers</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://beebegames.kodingen.com/">Beebe Games</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.astrolog.org/labyrnth/maze.htm">Think Labyrinth: Computer Mazes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.youtube.com/watch?v=0OzWIFX8M-Y">YouTube - Basshunter - Dota</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://najle.com/">MATIAS NAJLE</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.geekosystem.com/8-bit-game-demakes/">The Video Games of Today Reimagined in 8 and 16 Bits</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.justbenice.ru/">Just Be Nice</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://code.google.com/p/bwapi/">bwapi -  Project Hosting on Google Code</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tgbus.com/">::TGbus.com::中国电视游戏第一门户-电玩巴士</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://vimeo.com/9605639">Conrad Barski talking about "Common Lisp" and "Land of Lisp" at Philly Lambda on Vimeo</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sevenforums.com/tutorials/316-compatibility-mode.html">Compatibility Mode - Windows 7 Forums</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.generation-msx.nl/">Generation MSX - Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.dgob.de/">Deutscher Go-Bund e.V.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://fractionbars.com/Multiplication_Game/">Fraction Bars Multiplication Game</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://p2pu.org/webcraft/course-listing">Webcraft courses | p2pu</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://qanta.jp/screenname/">SCREEN NAME</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://enterzon.com/">EnterZon</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cavestory.org/index.php">Cave Story (Doukutsu Monogatari), A Tribute Site</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.smokymonkeys.com/triglav/">TRIGLAV</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bbc.co.uk/education/mathsfile/index.shtml">BBC - Schools - Mathsfile</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.quia.com/pop/35971.html">Quia - Context Clues</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.valuesatplay.org/">Values at Play » About Values at Play™</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.audiogames.net/page.php?pagefile=articles">AudioGames, your resource for audiogames, games for the blind ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dictionary.reference.com/fun/missspell">Free Word Game on Most Commonly Misspelled Words | Play Miss Spell's Class Game on Dictionary.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cssplay.co.uk/menu/amazing.html">Stu Nicholls | CSSplay | An amazing CSS puzzle</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.lazeroids.com/">LAZEROIDS!!! — massively-multiplayer html5 asteroids</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.codza.com/making-seamless-repeating-backgrounds-photoshop-cocos2d-iphone">codza » making seamless repeating backgrounds using photoshop and cocos2d iPhone</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.primarygames.com/holidays/halloween/games/mazes/trick-or-treat.htm">Halloween Match Game - PrimaryGames.com - Free Games for Kids</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.so-touch.com/?id=software&content=air-presenter#/software/air-presenter">So touch Air Presenter Plus | Create your own gestures presentations - Multi-touch gestures software</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.makeuseof.com/tag/top-10-free-online-tycoon-games-you-should-play/">Top 10 Free Online Tycoon Games You Should Try</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bencloward.com/resources.shtml">Character Animator | 3D Resources</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gamek.sakura.ne.jp/mhp2/index.html">MHP2nd 情報サイト -karikariP-</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gdconf.com/">Game Developers Conference 2007</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.refused-classification.com/">Refused Classification-Film Censorship in Australia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.powerupthegame.org/home.html">PowerUp the Game</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vgboxart.com/">VGBoxArt - Video Game Box Art / Covers</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mapeditor.org/">Tiled Map Editor</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.makeuseof.com/tag/10-free-online-picture-games-based-flickr-fun-learning/">10 Free & Fun Online Picture Games Based On Flickr</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sportforpeople.blogspot.com/2011/03/can-kentucky-slow-down-ohio-state.html">Will Kentucky Decelerate The Ohio State Freight Train?</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://faqs.ign.com/articles/854/854505p1.html">Final Fantasy III Job FAQ/guide - IGN FAQs</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cardkingdom.com/">Magic The Gathering, magic cards, singles, card lists, deck ideas.</a>
</span>
</li>
</ol>
<h2>environment</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://tinyhouseblog.com/">Tiny House Blog - Living Simply in Small Spaces</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.frieze.com/comment/article/nature_and_anti_nature/">Frieze Magazine | Comment | Nature and Anti-Nature</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/Uneconomic_growth">Uneconomic growth - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.teslamotors.com/about">About Tesla | Tesla Motors</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sciencemasters.com/ScienceMastersHome/tabid/36/Default.aspx">Science Masters > ScienceMasters Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://seedmagazine.com/content/print/urban_resilience/">Urban Resilience § SEEDMAGAZINE.COM</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.youtube.com/watch?v=sQIzoLURl2g">Earth Day video for kids</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.opengreenmap.org/greenmap/san-francisco-green-map">San Francisco Green Map | Open Green Map</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thecoolhunter.net/article/detail/1777/urban-station--buenos-aires">The Cool Hunter - Urban Station - Buenos Aires</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.interstation3d.com/tutorials.html">Interstation3d.com - Tutorials</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.coolpeoplecare.org/">Cool People Care | Saving the World, Five Minutes at a Time | Information, Inspiration & Local Events</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nytimes.com/2011/05/04/world/04population.html?_r=1">U.N. Forecasts 10.1 Billion People by Century’s End - NYTimes.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.joelsartore.com/">Joel Sartore Photography</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://iufro-archive.boku.ac.at/silvavoc/carbon-glossary/">Multilingual Glossary of carbon-related forest terminology</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://brillstreet.com/p/generationy50/">2009 Top Gen-Y companies to work for in Chicago</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.talking-tree.com/">Talking Tree</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.storyofstuff.com/international/">The Story of Stuff with Annie Leonard</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ferc.gov/">Federal Energy Regulatory Commission</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vandanashiva.org/">Reconnecting Farmers, Society and the Earth | Vandana Shiva – Navdanya International</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.productecologyonline.com/www/">Product Ecology</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://energybulletin.net/">Energy Bulletin</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.reuk.co.uk/index.htm">Renewable Energy UK</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mcgi.state.mi.us/environmentalmapper/">MCGI</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://fora.tv/2009/01/16/Saul_Griffith_Climate_Change_Recalculated">Saul Griffith: Climate Change Recalculated</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.jacovox.com/2010/03/100-anuncios-para-grandes-causas/">100 Anuncios para grandes causas | JacoVox</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nikebiz.com/responsibility/nikeenvironmentaldesigntool">www.nikebiz.com/responsibility/nikeenvironmentaldesigntool</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://10000birds.com/">10,000 Birds: Birding, blogging, conservation, and commentary</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://the-planet-zero.com/">THE PLANET ZERO</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://computingforsustainability.wordpress.com/2009/03/15/visualising-sustainability/">Visualising sustainability « Computing for Sustainability</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.planning-applications.co.uk/">planning-applications.co.uk</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ecodebate.com.br/">Portal EcoDebate - Cidadania e Meio Ambiente</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.naturemoms.com/no-shampoo-alternative.html">The No Shampoo Alternative</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.spiked-online.com/index.php?/site/article/4275/">The tyranny of science | spiked</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://web.mit.edu/newsoffice/2011/transparent-solar-windows-0415.html">Turning windows into powerplants</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.solartopia.org/">Solartopia*</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.organic-gardening.net/">Organic Gardening Tips, Information, & Advice</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.livinggreener.gov.au/">LivingGreener.gov.au</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.co-operative.coop/join-the-revolution/">Join the Revolution</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ted.com/talks/michael_pritchard_invents_a_water_filter.html">Michael Pritchard's water filter turns filthy water drinkable | Video on TED.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nwf.org/Get-Outside/Be-Out-There/Why-Be-Out-There/What-is-a-Green-Hour.aspx">What is a Green Hour? - National Wildlife Federation</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.globalonenessproject.org/videos/athousandsuns">A Thousand Suns | Global Oneness Project</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.physorg.com/news/2011-04-common-nanoparticles-highly-toxic-arctic.html">Common nanoparticles found to be highly toxic to Arctic ecosystem</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gardenpool.org/">GardenPool.org | How we turned an old backyard swimming pool into a self-sufficient garden in a desert city.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.good.is/post/transparency-how-much-does-the-united-states-subsidize-energy/">How Much Does the United States Subsidize Energy</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.worldchanging.com/archives/004599.html">WorldChanging: Tools, Models and Ideas for Building a Bright Green Future: Personal Factor Four: Organizing Real Environmental Action With The Internet</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.learner.org/resources/series85.html">Resource: Human Geography: People, Places, and Change</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.andreapolli.com/">http://www.andreapolli.com/</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://eco-escolas-portugal.blogspot.com/">Eco-Escolas em Portugal</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.stopglobalwarming.org/">StopGlobalWarming.org</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://animal.discovery.com/guides/endangered/endangered.html">Endangered Species Guide - Animal Planet</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.enviroschools.org.nz/">Enviroschools : Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.newtonmarascofoundation.org/programs/a_ge_pw.cfm">Newton Marasco Foundation</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fastcompany.com/1721519/a-look-inside-nasas-sustainability-base">NASA's First Space Station on Earth: A Look Inside the Sustainability Base | Fast Company</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.greendepot.com/greendepot/">Green Building Supplies | Green Depot: Environmental Building Supplies.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.humancar.com/">HumanCar® Inc. Imagine_PS™ electric car NextFest 2008!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://squid.tepapa.govt.nz/">The Colossal Squid Exhibition</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.greatapeproject.org/declaration.php">GAP---Great Apes Project</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.youtube.com/watch?v=hhyQ0HES8mM">The Postmodern City / Bonaventure Hotel</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ecobee.com/">ecobee - Programmable Thermostats and Other Green Living Products</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.theweathermakers.org/">The Weather Makers, by Tim Flannery</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gm.com/corporate/responsibility/education/">GM - Education - Index</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.accionatura.org/">Acciónatura</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://letsgogreen.biz/">Eco-friendly Green Products for Every Home, Office or Business</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.eco-storm.com/">eco-storm.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wolfquest.org/index.php">WolfQuest</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.shopequita.com/">Equita - Essentials for Ethical Living - Fair Trade + Organic + Green</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.unglobalcompact.org/">United Nations Global Compact</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://art.webesteem.pl/9/wyman_en.php">webesteem art & design magazine : Lance Wyman : Wayfinding Systems : Case Study</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://winslowgreen.com/home/">Winslow Management, Winslow Green Growth Fund, Environmentally Responsible Investing</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tarsandswatch.org/">Tar Sands Watch</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.conifers.org/">The Gymnosperm Database: Home Page</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.epa.gov/epawaste/education/toolkit.htm">Tools to Reduce Waste in Schools | Resources for Waste Education | US EPA</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.eco-button.com/">ECO BUTTON ™ one small click one big change</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.midwestenergynews.com/">Midwest Energy News</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.faithinplace.org/">Faith In Place</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.esa.int/esaKIDSen/SEM2WKXJD1E_Earth_0.html">ESA - Kids - Earth - Pollution</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.intoeternitythemovie.com/">Into Eternity The Movie - Opens February 2 in the US</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.realclimate.org/index.php/archives/2009/04/aerosol-formation-and-climate-part-i/">RealClimate: Aerosol formation and climate, Part I</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://cnps.org/">CNPS - California Native Plant Society</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wholeearth.com/index.php">Whole Earth Catalog: Access to Tools and Ideas</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.physicalgeography.net/">Geography : Physical Geography</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.energystar.gov/index.cfm?fuseaction=rebate.rebate_locator">ENERGY STAR</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.pfcenergy.com/">PFC Energy Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.learner.org/interactives/garbage/solidwaste.html">Garbage-- Solid Waste</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.pbs.org/wnet/savageearth/">SAVAGE EARTH Online</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.greenling.com/">Greenling Organic Delivery - Local food and Organic produce and groceries home delivered - Austin and San Antonio</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.chinafaqs.org/blog-posts/how-does-chinas-12th-five-year-plan-address-energy-and-environment">How does China’s 12th Five-Year Plan address energy and the environment? - ChinaFAQs</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://arxiv.org/abs/0909.2789">[0909.2789] Quantum Probability Explanations for Probability Judgment 'Errors'</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.indissoluble.com/">Indissoluble Arquitectura, diseño y montaje de exposiciones, arquitectura efímera, stands, estands. Barcelona</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.naturalnews.com/031084_bird_deaths_holocaust.html">U.S. government commits avian holocaust with mass poisoning of millions of birds</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nytimes.com/2011/04/29/business/energy-environment/29utility.html">Nuclear Reactor Projects Falter - May 2011 - NYT</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.goodbeachguide.co.uk/">Good Beach Guide</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.redr.org/">RedR</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.independent.co.uk/environment/nature/britains-taste-for-cheap-food-thats-killing-brazils-other-wilderness-2266062.html">Britain's taste for cheap food that's killing Brazil's 'other wilderness' - Nature, Environment - The Independent</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gcmd.nasa.gov/KeywordSearch/Home.do?Portal=GCMD&MetadataType=0">NASA Global Change Master Directory</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.usgs.gov/science/">Science Topics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://nationaljournal.com/magazine/the-human-footprint-20110414">NationalJournal.com - The Human Footprint - Friday, April 15, 2011</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.shft.com/">SHFT</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
</ol>
<h2>healthcare</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.interfaceware.com/hl7/how-does-hl7-work/">How does HL7 work? - iNTERFACEWARE</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.ceridian-benefits.com/">Ceridian Benefit Services</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.americanhealthcare.com/ahc/">AHC Home Page</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.aok-gesundheitsnavi.de/">AOK-Gesundheitsnavi - Startseite</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.epsos.eu/">epSOS: Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gelconference.com/videos/health_09/bridget_duffy_1/">Video of Bridget Duffy at Gel Health '09 - Gel Videos</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://qualityforum.org/Home.aspx">National Quality Forum:  Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.healthline.com/index.jsp">Healthline - Connect to Better Health</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.equalitytrust.org.uk/why/evidence">The Evidence in Detail | The Equality Trust</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://openmhealth.org/">Open mHealth | A Center for Embedded Networked Sensing (CENS) Project</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.uhhospitals.org/">University Hospitals | Cleveland, OH</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.unnaturalcauses.org/">UNNATURAL CAUSES | CALIFORNIA NEWSREEL</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mooncup.co.uk/">Mooncup Menstrual Cup | Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nytimes.com/2011/05/14/business/14health.html">Health Insurance Profits Rise</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thisamericanlife.org/radio-archives/episode/392/someone-elses-money">Someone Else's Money | This American Life</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.filmsforaction.org/">Films For Action | Watch Over 700 Videos Hand-Picked to ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wired.com/wiredscience/2011/04/resistance-what-works/">World Health Day update: Use an antibiotic, pay a fee? | Wired Science | Wired.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.soterawireless.com/main/">Sotera Wireless - Rapid Response Monitoring: A new era in ambulatory patient safety - Welcome to the Frontpage</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archimedesmodel.com/">Archimedes - Healthcare Modeling</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.iom.edu/Reports/2011/Finding-What-Works-in-Health-Care-Standards-for-Systematic-Reviews.aspx">Finding What Works in Health Care: Standards for Systematic Reviews - Institute of Medicine</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.whitehouse.gov/taxreceipt">Your 2010 Federal Taxpayer Receipt | The White House</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fastcompany.com/magazine/104/sparc.html">A Prescription for Innovation</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://techcrunch.com/2011/05/13/cake-health-wants-to-be-the-mint-for-health-insurance-beta-invites/">Cake Health Wants To Be The ‘Mint For Health Insurance’ (Beta Invites)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gold.ahrq.gov/projectsearch/">Grants On-Line Database</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cms.gov/NationalHealthExpendData/">Overview National Health Expenditure Data</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.eclinicalworks.com/">EMR - Electronic Medical Records and Practice Management for Clinical Practices by eClinicalWorks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.womenonweb.org/">women on web</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.imshealth.com/portal/site/imshealth">Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://thinkprogress.org/2011/04/05/ryan-repeatedly-medicare-cuts/">ThinkProgress » FLASHBACK: Ryan Repeatedly Attacked Democrats For Supposedly Raiding And Cutting Medicare</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.who.int/ictrp/en/">WHO | Welcome to the WHO ICTRP</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.artsusa.org/2011/04/20/the-top-10-reasons-to-support-the-arts/#more-8059">ARTSblog » Blog Archive » The Top 10 Reasons to Support the Arts (from Arts Watch)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://prforpharma.com/">Pharmaceutical Social Media and PR: PRforPharma</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bvmi.de/">Berufsverband Medizinischer Informatiker e.V. /</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.washingtonpost.com/blogs/right-turn/post/exclusive-interview-romneycare-author-jonathan-gruber/2011/03/04/AF2WJorB_blog.html">EXCLUSIVE INTERVIEW: RomneyCare author Jonathan Gruber</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.medicalsmartphones.com/">Medical Smartphones [part of HCPLive]</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ahrq.gov/questionsaretheanswer/">Questions Are the Answer - medical care</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.msnbc.msn.com/id/42960543/ns/health-cancer/">Gay men nearly twice as likely to report having cancer (MSNBC)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.healthline.com/aboutus.jsp">Healthline - About Us</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.washingtonpost.com/blogs/ezra-klein/post/the-three-most-important-health-care-graphs-in-the-world/2011/04/13/AFtU1E6E_blog.html">The three most important health-care graphs in the world - Ezra Klein - The Washington Post</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.massivehealth.com/">Massive Health</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://pewresearch.org/pubs/1989/health-care-online-social-network-users">The Social Life of Health Information, 2011 - Pew Research Center</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.slate.com/id/2281588/">A pre-existing health-conditions study says half the country is uninsurable. - By Timothy Noah - Slate Magazine</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.medpagetoday.com/">http://www.medpagetoday.com/</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.sundhed.dk/">sundhed.dk - About The eHealth Portal</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.readwriteweb.com/cloud/2010/11/3-mobile-healthcare-apps-that.php">3 Mobile Healthcare Apps that Leverage the Cloud - ReadWriteCloud</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blogs.wsj.com/health/2011/04/22/are-patients-the-same-as-consumers/">Are ‘Patients’ the Same as ‘Consumers’? - Health Blog - WSJ</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fiercehealthit.com/">FierceHealthIT - Health IT, healthcare it news, health informatics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://shirleymedical.com/news/sleep-apnea-is-more-than-a-snoring-problem">Sleep Apnea Is More Than A Snoring Problem</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.caregiving.org/">National Alliance for Caregiving</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://nppes.cms.hhs.gov/NPPES/NPIRegistryHome.do">NPI Registry Search Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.apple.com/science/medicine/practicemanagement/">Apple - Science - Medicine - Practice Management</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ebri.org/">Employee Benefit Research Institute | EBRI</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ajmc.com/">AJMC - American Journal of Managed Care</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sectorpublic.com/2010/11/xbox-kinect-applications-to-health-and-medicine/">Xbox Kinect Applications To Health And Medicine | SECTOR: PUBLIC</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.elitehealth.com/view_news.php?nid=1144">Concierge Healthcare Provider EliteHealth Announces New Philadelphia Location</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://37signals.com/svn/posts/2878-shaking-up-the-bizarre-habits-ingrained-in-primary-health-care">Shaking up the bizarre habits ingrained in primary health care - (37signals)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ihe-europe.net/">IHE-Europe Home Page</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.floridahospital.com/">Florida Hospital | Orlando's Most Preferred Hospital | Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://clinicaltrials.gov/ct2/home">ClinicalTrials.gov</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.live365.com/index.live">Live365 Internet Radio - Thousands of Free Online Radio Stations</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://online.wsj.com/article/SB10001424052748703858404576214642193925996.html">Medicare Records Reveal Troubling Trail of Surgeries - WSJ.com</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ihealth99.com/">iHealth Blood Pressure Monitor for iPhone & iPad in iHealth.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="https://www.drimpy.com/">Welkom bij Drimpy | Drimpy : Brengt zorg samen</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ekahau.com/solutions/healthcare.html">Wi-Fi Healthcare Tracking Solutions | Ekahau hospital RTLS</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wtflungcancer.com/">WTFLungCancer — My mom has lung cancer. She has never smoked ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.centerwatch.com/">CenterWatch</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.qualityforum.org/Home.aspx">NQF:Home</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://guidelines.gov/">NGC - National Guideline Clearinghouse</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.informedmedicaldecisions.org/index.html">Informed Medical Decisions - Information To Make Sound Medical Decisions</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.emrandhipaa.com/wiki/EMR_and_EHR_Matrix">EMR and EHR Matrix - EMR, EHR and HIPAA Wiki</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.slate.com/id/2275877/">Crap health coverage wins a regulatory victory. - By Timothy Noah - Slate Magazine</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ceridian.com/">Ceridian Payroll & Human Resources Solutions</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www11.georgetown.edu/research/gucchd/nccc/">National Center for Cultural Competence</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mieweb.com/">Home-Medical Informatics Engineering</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://telushealth.com/en/default.aspx">TELUS Health - Information and Communication Technology Solutions for Healthcare</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wittere-tanden.com/">Ontvang elk seizoen een nieuwe tandenborstel › Wittere-tanden.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fibroandfatigue.com/">Fibromyalgia & Fatigue Center</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.kaiserhealthnews.org/Stories/2011/January/13/ACO-accountable-care-organization-FAQ.aspx">FAQ On ACOs: Accountable Care Organizations, Explained - Kaiser Health News</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://hcr.propublica.org/document/show/1.html">Side by Side: Health Care Bills | ProPublica</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.emedicinehealth.com/back_pain/article_em.htm">Back Pain</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://informaticsprofessor.blogspot.com/">Informatics Professor</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/Laboratory_information_management_system">Laboratory information management system - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.everydayhealth.com/">Health Information, Resources, Tools & News Online - EverydayHealth.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.slideshare.net/jdlasica/top-10-pharma-efforts-in-social-media">Top 10 Pharma Efforts In Social Media</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://nnlm.gov/mar/about/value.html">NN/LM MAR Value of Libraries Study</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.rekenkamer.nl/">Algemene Rekenkamer</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wired.com/medtech/health/news/2004/10/65252">People Are Human-Bacteria Hybrid</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nypost.com/p/news/opinion/opedcolumnists/doc_holiday_Nyb5JCHkWyejLq7dTjTs2J">Doc holiday - NYPOST.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.pewinternet.org/Reports/2011/Social-Life-of-Health-Info.aspx">The Social Life of Health Information, 2011 | Pew Research ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.parc.com/event/936/innovation-at-google.html">Event - Innovation at Google: the physics of data - PARC (Palo Alto Research Center)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sermo.com/">Sermo - Know more. Know earlier.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/Migraine">Migraine - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.businessweek.com/bwdaily/dnflash/content/jun2009/db20090617_759590.htm">Wal-Mart Medical Clinics Stumble</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mobih.org/">mHealth</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.onemedical.com/">e-Health 2.0 - Gestión de tu Agenda Medica</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.healthywage.com/">Losing Weight - Making Money - HealthyWage</a>
</span>
</li>
</ol>
<h2>harrypotter</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hpfandom.net/eff/viewstory.php?sid=18470">To Heal a Soul</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://magog-83.livejournal.com/53039.html">A Ministerial Appointment | merlin / harry potter</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://scarhead.net/">Potter Slash Archive ::</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nightroadsassoc.com/beautifulboy.htm">Beautiful Boy</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://hp.adultfanfiction.net/story.php?no=600010089">Story: Bigger is Better</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://foryourpleasure.dreamwidth.org/4416.html">foryourpleasure | Harry Potter: Harry/Draco Recs, Post Hogwarts</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://community.livejournal.com/hd_career_fair/30584.html">hd_career_fair: FIC: When the Clocks Stopped</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.walkingtheplank.org/archive/viewstory.php?sid=1646">Master Snape's Community by Rakina</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.notquiteroyal.net/topgallant/fics/the_reader.html">Topgallant : HP : The Reader</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thebejeweledgreenbottle.com/2007%20winter%20games/Team%20Wartime/PIR8FANCIER2.htm">Help Wanted: God and Executioner</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.moonpants.org/txt/shuffle-ofakind.html">writing - shuffle: of a kind</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://liadan14.livejournal.com/31469.html">Light Unshone</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.intimations.org/fanfic/hp/DeepAsYouGo.html">Deep As You Go</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://xylodemon.livejournal.com/444662.html">19½ First Dates</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thepetulantpoetess.com/index.php">The Petulant Poetess :: Fiction Archive</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://megyal.livejournal.com/253046.html">HP: Harry Potter and the Incredibly Organized Personal Assistant, H/D, PG, 2K</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.dragonlight.slashcity.org/mirrors/fic/ex/paradox/poechapter.htm">The Paradox of Existence by DragonLight</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://small-gardens.livejournal.com/6268.html">[HP - Albus/Scorpius] Bryoney Brynn – Through Harry’s Eyes</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://bigbang.inkubation.net/bbb3/nightingale.html">Nightingale</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://byblythe.livejournal.com/20625.html">corridors of power</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://community.livejournal.com/the_ass_ship/90731.html?style=mine">Drinking coffee or reading lies</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gatewaygirl.insanejournal.com/82742.html">gatewaygirl - A Confusion of Will and Desire, H/D, EWE, NC-17, 1 of 9</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://red-squared.livejournal.com/18901.html">If I'm a fool for you</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bigbang.inkubation.net/qoh.html">Queen of Hearts by Duke and Betty (aka cynicalpirate and scoradh)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.mcamy.net/snapefic/honor/honor.html">A Matter of Honor</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dreamdustmama.livejournal.com/25192.html">dreamdustmama: Better Than You - Chapter One</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://emmagrant01.livejournal.com/481526.html">Fast Forward, Two Steps Back</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://grazhir.com/hp/cp/00.php">Crumbling Pedestal</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=14290">Surrender the Grey</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fictionalley.org/authors/jackson_rayne/JLT01a.html">Astronomy Tower - Just Like This (Story Text)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thebejeweledgreenbottle.com/2007%20winter%20games/Team%20Wartime/Two%20Lockets,%20by%20Sinick%20and%20Acid.htm">ac1d6urn & sinick - Two Lockets</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.shadowess.com/snarryathon/Felinated.html">felinated</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.dementia.org/~jacquez/writing/fanfic.html">devilmonkey press fanfiction : jacquez</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.permedjed-designs.net/starkindler/hpfics/sageadvice.html">"Sage Advice" by Starkindler</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.youtube.com/watch?v=7GpZpoaZaSE">So You Want to be a Masonomist</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://cjmarlowe.livejournal.com/322254.html">Why didst thou promise such a beauteous day</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hpfandom.net/eff/viewstory.php?sid=3397">Malfoy Child</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://beren-writes.livejournal.com/70502.html">Angels and Devils</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://fandomania.com/fandomestic-12-harry-potter-my-little-ponies/">Fandomestic: 12 Harry Potter My Little Ponies | Fandomania</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://rosemaryandrue.livejournal.com/53314.html#cutid1">Those Frightful Malfoy Scenes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://magog-83.livejournal.com/28717.html">Meeting the Minister</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thesilversnitch.net/tss1/viewstory.php?sid=15116&warning=6">Into the Light of the Dark Black Night</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://theguestroom.houseofhobbits.com/hp/Trinity.html">Trinity by Mirabella</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://furiosity.livejournal.com/607098.html">To Hell and Back</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://mosca.livejournal.com/237505.html">That Teenage Feeling, by mosca</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=4093&chapter=1&font=&size=">skyehawke :: archives :: :: Story :: Left My Heart</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://pir8fancier.livejournal.com/152794.html#cutid1">pir8fancier: pir8's Masterlist of Fics</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.walkingtheplank.org/archive/viewuser.php?uid=477">Walking The Plank :: Dianann</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://sam-storyteller.dreamwidth.org/31527.html">Cartographer's Craft by copperbadge / sam_storyteller</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.livejournal.com/tools/memories.bml?user=maxine_chan&keyword=Fic-HP:+Starts+With+a+Spin&filter=all">Memorable Fic-HP: Starts With a Spin Entries</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=12808&chapter=1&font=&size=">FIC: Single Wizard Seeking Same</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ravenswing.com/~keelywolfe/foresight.html">A Lacking of Foresight</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thequidditchpitch.org/viewstory.php?sid=6379&chapter=1">Of Cabbages and Kings</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://trickofthedark.livejournal.com/31959.html">HP Widdershins: Part 1.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archiveofourown.org/works/137248">And On The Third Day by <user name="lalaietha" site="archiveofourown.org"></a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=261">skyehawke :: archives :: :: Story :: Seeker to Seeker</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dracosoftie.livejournal.com/4530.html">Ron Weasley is a Kinky Slut by dracosoftie</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://faithwood.livejournal.com/172711.html">Ferocious Determination, Insufficient Deliberation, and a Slightly Wrong Destination</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://snarry-reader.livejournal.com/">The Essential Snarry Reader</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://community.livejournal.com/bandombigbang/88386.html">bandombigbang: Imagine Knowing Me by fannyt</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://community.livejournal.com/hd_holidays/137715.html">hd_holidays: HAPPY H/D HOLIDAYS, FAITHWOOD!</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://asylums.insanejournal.com/percy_ficathon/22131.html">Six Impossible Things (Before Breakfast)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thebejeweledgreenbottle.com/OLYMPICS%20FICS/ROMANCE%207%20YEAR%20ITCH.htm">Seven Year Itch</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=9924&font=&size=">skyehawke :: archives :: :: Story :: Intrepid Teenage Hero</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://toftier.livejournal.com/12353.html">Harry + Ginny 4ever! [tradescent]</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.amanuensis1.com/droitduseigneur.html">Droit Du Seigneur</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=9173&chapter=1">Lines</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.caffiends.net/viewstory.php?sid=110">Little Stone Heart by Kat Reitz and Tzigane</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=15108">The Third</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://gestaltrose.livejournal.com/48266.html">Rose's Room - Making Choices - Crossover Big Bang - NC-17</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.livejournal.com/tools/memories.bml?user=nishizono&keyword=The+Venice+Job&filter=all">Memorable The Venice Job Entries</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://ashwinder.sycophanthex.com/viewstory.php?sid=9325">What E'er Therein Is Promised by Deeble</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tthfanfic.org/Series-123">TtH • Series • A Changed World Series</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.greyblue.net/MidnightBlue/story.php?storyid=2">Mirror of Maybe</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.walkingtheplank.org/archive/viewstory.php?sid=1295">Unstrung Heroes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://saras-girl.livejournal.com/32274.html#cutid1">Sardinian Blue - Talk to Me [oneshot] 1/3</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.walkingtheplank.org/archive/viewstory.php?sid=2940">A Time to Forget by GatewayGirl</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bigbang.inkubation.net/life.html">Life Less Frightening</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://community.livejournal.com/kissesforcrises/3826.html">Tread Softly (PG-13)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archive.skyehawke.com/story.php?no=4573">Change My World</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://alaana-fair.livejournal.com/161384.html">Desperately Seeking Someone – Life Goes On</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.hdcareerfair.de/224_fic.html">Pomegranate</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.sechs.hdhols.com/for_bryoneybrynn.html">The Waters Know Their OWn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thebejeweledgreenbottle.com/OLYMPICS%20FICS/TEAM%20ANGST%20DOLLHOUSE.htm">Fic: Contrapasso by Rex Luscus</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://community.livejournal.com/hp_tng/10753.html">you always hurt the ones you love (Teddy/James, PG)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://dracobigbang.accio.nu/fics/20.htm">Hard Knocks by Iennanightrunner</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.striped-wrappers.com/afest/gift-for-sesheta.html">Through Harry’s Eyes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://en.wikipedia.org/wiki/Lord_Voldemort">Lord Voldemort - Wikipedia, the free encyclopedia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.walkingtheplank.org/archive/index.php">Walking The Plank   Snape/Harry archive</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.walkingtheplank.org/archive/viewstory.php?sid=820&warning=4">Snape: The Home Fries Nazi by pir8fancier</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://femmenerd.livejournal.com/258498.html">Choices (Five Ways Hermione Granger Could Have Lost Her Virginity) - femmenerd</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.walkingtheplank.org/archive/viewstory.php?sid=2217&index=1">The Care Of Infants by Perfica</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://archiveofourown.org/works/197759">Gryffindor Is Not Synonymous With Indestructible, You Idiot</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.debbiesfics.com/hp.html">Debbie's Collection: Harry Potter</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://community.livejournal.com/hd_holidays/93652.html">HP: Now The Shining Sun Is Up, H/D, PG-13, 23K</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://angelgazing.livejournal.com/7664.html">And we are at our apogee harry/draco</a>
</span>
</li>
</ol>
<h2>vegetarian</h2>
<ol>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.101cookbooks.com/archives/spicy-cauliflower-with-sesame-recipe.html">Spicy Cauliflower with Sesame Recipe - 101 Cookbooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vegetariantimes.com/recipes/11477?section=">Broccoli Slaw Salad with Five-Spice Tofu Recipe</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thekitchn.com/thekitchn/tips-techniques/snack-on-the-go-veggies-stored-in-dip-093247">Snack On The Go: Veggies Stored In Dip | Apartment Therapy The Kitchn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.newyorker.com/arts/critics/books/2009/11/09/091109crbo_books_kolbert">Jonathan Safran Foer’s “Eating Animals” and vegetarianism review : The New Yorker</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tammysrecipes.com/spinach_rice_casserole">Spinach Rice Casserole | Tammy's Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seriouseats.com/recipes/2011/03/soba-noodles-with-eggplant-and-mango-recipe.html">Cook the Book: Soba Noodles with Eggplant and Mango</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thekitchn.com/thekitchn/summer/easy-recipe-tomatillo-salsa-121686">Easy Recipe: Tomatillo Salsa | Apartment Therapy The Kitchn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.foodnetwork.com/recipes/giada-de-laurentiis/penne-with-spinach-sauce-recipe/index.html">Penne with Spinach Sauce Recipe : Giada De Laurentiis : Food Network</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.anjasfood4thought.com/2011/01/spiced-cauliflower-apple-soup.html">Anja's Food 4 Thought: Spiced Cauliflower Apple Soup</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.foodnetwork.com/recipes/ellie-krieger/rice-and-black-bean-pilaf-recipe/index.html">Rice and Black Bean Pilaf Recipe : Ellie Krieger : Food Network</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thedailygreen.com/healthy-eating/recipes/vegan-scone-recipe">Vegan Scone Recipe - Tomato Rosemary Scone Recipe - The Daily Green</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.eatingwell.com/recipes/lemon_sardine_pasta.html">Lemon-Garlic Sardine Fettuccine | Eating Well</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://foodblogga.blogspot.com/">Food Blogga</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://picky-palate.com/2009/08/24/poppin-garlic-ranch-biscuit-topped-chicken-pot-pie/">Poppin’ Garlic Ranch Biscuit Topped Chicken Pot Pie… | Picky Palate</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.poussepousse.eu/">Pousse-Pousse : alimentation bio</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.foodandwine.com/recipes/cumin-spiced-red-lentil-burgers">Cumin-Spiced Red Lentil Burgers Recipe - Ann Withey | Food & Wine</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.indianfoodforever.com/north-indian-vegetarian-recipes.html">North Indian Vegetarian Recipes - North Indian Veg Dishes - North ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.care2.com/greenliving/quick-black-bean-soup-recipe.html">Quick Black Bean Soup Recipe | Care2 Healthy & Green Living</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.gourmet.com/recipes/2000s/2009/02/buttermilk-fantails">Buttermilk Fantails</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.epicurious.com/recipes/food/views/Quick-Moroccan-Vegetable-Couscous-1194">Quick Moroccan Vegetable Couscous Recipe at Epicurious.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://allrecipes.com/Recipe/Easy-Cream-Cheese-Danish/Detail.aspx">Easy Cream Cheese Danish Recipe - Allrecipes.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.perrysplate.com/2011/03/stacked-roasted-vegetable-enchiladas.html">Perry's Plate: Stacked Roasted Vegetable Enchiladas</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://blog.fatfreevegan.com/2008/04/cinnamon-swirl-muffins.html">Cinnamon Swirl Muffins | recipe from FatFree Vegan Kitchen</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://simplyrecipes.com/recipes/rustic_onion_tart/">Rustic Onion Tart</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seriouseats.com/recipes/2011/01/eat-for-eight-bucks-black-bean-and-sweet-potato-chili-recipe.html">Eat For Eight Bucks: Black Bean and Sweet Potato Chili | Serious Eats : Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.bbc.co.uk/food/recipes/griddledartichokeand_91479">BBC - Food - Recipes : Griddled artichoke and red onion paella</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://vegetarian.about.com/od/vegetarianindianrecipes/r/yellowdhal.htm">Yellow Split Pea Dhal Recipe - Vegetarian Indian Food - Easy Vegan Indian Recipe - How to Cook Dhal - Dal - Indian Rice and Dahl</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://allrecipes.com/Recipe/Quinoa-Tabbouleh/Detail.aspx">Quinoa Tabbouleh Recipe - Allrecipes.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.grouprecipes.com/19103/everyday-red-lentil-dal.html">Everyday Red Lentil Dal Recipe</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tammysrecipes.com/mexican_black_bean_burgers">Mexican Black Bean Burgers | Tammy's Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.veggienumnum.com/2011/04/coriander-nori-%E2%80%98pesto%E2%80%99-soba-w-wok-seared-greens/">Veggie num num : Coriander & Nori ‘Pesto’ Soba w/ Wok Seared Greens</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.quickandsimple.com/diet-weight-loss/tips-calculator/belly-fat-foods">12 Foods That Burn Belly Fat - Quick & Simple</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://kblog.lunchboxbunch.com/2010/11/easy-tahini-curried-carrot-salad-spicy.html">Easy Tahini Curried Carrot Salad. Spicy-Sweet. - Healthy. Happy. Life.</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nytimes.com/2009/07/29/health/nutrition/29recipehealth.html">Thai Combination Fried Rice</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://virtuallyveganmama.blogspot.com/2011/04/toasted-quinoa-mexican-soup.html">Virtually Vegan Mama: Toasted Quinoa Mexican Soup</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.101cookbooks.com/archives/brown-butter-tortelli-recipe.html">Brown Butter Tortelli Recipe - 101 Cookbooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seriouseats.com/recipes/2011/02/stovetop-chipotle-mac-cheese-recipe.html">Serious Heat: Stovetop Chipotle Mac and Cheese | Serious Eats : Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.101cookbooks.com/archives/summer-vegetable-cianfotta-recipe.html">Summer Vegetable Cianfotta Recipe - 101 Cookbooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://voraciouseats.com/2010/11/19/a-vegan-no-more/">A Vegan No More | Voracious</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.deliaonline.com/recipes/type-of-dish/vegetarian-food/vegetarian-moussaka-with-ricotta-topping.html">Vegetarian Moussaka with Ricotta Topping - Delia</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://weelicious.com/2011/05/10/roasted-honey-cinnamon-chickpeas/">Roasted Honey Cinnamon Chickpeas</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nomilk.com/">No Milk Page: Books & Links</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vegsource.com/">Vegan & Vegetarian Recipes, Articles, Health Resource</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.anhsfoodblog.com/2010/08/sticky-date-scones-international.html">Sticky date scones</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.food52.com/recipes/8565_mujaddara_with_spiced_yogurt">Mujaddara with Spiced Yogurt recipe from food52</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.cookinglight.com/food/quick-healthy/quick-easy-sandwich-recipes-00400000050417/page27.html">Open-Faced Sandwiches with Ricotta, Arugula, and Fried Egg Recipes < Superfast Sandwich Recipes - Cooking Light</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.crumblycookie.net/2011/02/23/braised-white-beans-with-zucchini-tomatoes-and-potatoes/">The Way the Cookie Crumbles » Blog Archive » braised white beans with zucchini, tomatoes, and potatoes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.food52.com/recipes/7020_red_lentil_and_cauliflower_soup">Red Lentil and Cauliflower Soup recipe from food52</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.themeaningofpie.com/2011/04/asparagus-and-radish-salad/">Asparagus, Radish, & Apple Salad with Mustard Viniagrette\</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.kpft.org/">KPFT 90.1 FM</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.nytimes.com/2009/07/22/dining/22mlist.html?pagewanted=1">The Minimalist - Recipes for 101 Simple Salads for the Season - NYTimes.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.tasteofbeirut.com/2011/04/the-monks-salad-salata-el-raheb/">The Monk’s salad (Salata el-raheb)</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thekitchn.com/thekitchn/main-dish/recipe-rich-nocream-wild-mushroom-pasta-sauce-041199">Recipe: Rich No-Cream Wild Mushroom Pasta Sauce | Apartment Therapy The Kitchn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.fitsugar.com/Snack-Attack-Nonfat-Yogurt-Dill-Dip-Veggies-3903452">Nonfat Yogurt Dill Veggie Dip</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thekitchn.com/thekitchn/side-dish/summer-side-dish-potatoes-green-beans-and-corn-in-lemon-brown-butter-sauce-121830?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+apartmenttherapy%2Fthekitchn+%28The+Kitchn%29">Potatoes, Green Beans, and Corn in Lemon Brown Butter Sauce | Apartment Therapy The Kitchn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://mehanskitchen.blogspot.com/2009/10/braised-kale-with-pasta.html">Mehan's Kitchen: Braised Kale with Pasta</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.foodandwine.com/recipes/cauliflower-potato-and-pea-curry">Cauliflower, Potato, and Pea Curry</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://allrecipes.com/Recipe/Three-Bean-Salad-5/Detail.aspx">Three Bean Salad Recipe - Allrecipes.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://bittersweetblog.wordpress.com/">BitterSweet</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thenourishinggourmet.com/2008/04/roasted-asparagus-2.html">Roasted Asparagus</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seriouseats.com/recipes/2009/03/curried-cauliflower-soup-with-honey-recipe.html">Healthy and Delicious: Curried Cauliflower Soup With Honey | Serious Eats : Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.101cookbooks.com/low_carb_recipes/">Low Carb Recipes - 101 Cookbooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.101cookbooks.com/archives/jamaican-veggie-patties-recipe.html">Jamaican Veggie Patties Recipe</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seriouseats.com/recipes/2011/05/goat-cheese-danishes-recipe.html">Goat Cheese Danishes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.khmerkromrecipes.com/">Welcom to khmerkromrecipes.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://kitchen-parade-veggieventure.blogspot.com/2005/10/day-208-roasted-beets-with-balsamic.html">Day 208: Roasted Beets with Balsamic Vinegar ♥ | A Veggie Venture</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://vegetarian.about.com/od/maindishentreerecipes/r/bulgurpilaf.htm">Vegetarian Bulgur Wheat Pilaf with Mushrooms - Bulgur Wheat Recipe - Bulgur Wheat Pilaf - Vegan Bulgur Wheat Recipe</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.guardian.co.uk/lifeandstyle/2009/aug/01/yotam-ottolenghi-vegetarian-tabbouleh">The new vegetarian: Yotam Ottolenghi's tabbouleh | Life and style | The Guardian</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.guardian.co.uk/lifeandstyle/2010/jul/24/one-pot-recipe-yotam-ottolenghi">One-pan wonder recipe | Yotam Ottolenghi | Vegetarian | Food | Life and style | The Guardian</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.epicurious.com/recipes/food/views/Quinoa-with-Black-Beans-and-Cilantro-243392">Quinoa with Black Beans and Cilantro Recipe at Epicurious.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.quickindiancooking.com/2007/03/16/aloo-gobi/">Aloo gobi – no introduction needed « Quick Indian Cooking</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.beyondveg.com/billings-t/bio/billings-t-bio-1a.shtml">Tom Billings: dietary bio, Part A</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.quarrygirl.com/2011/04/13/rant-veg-news-is-putting-the-meat-into-vegan-issues/">RANT: VegNews is putting the MEAT into vegan issues | quarrygirl.com</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.saveur.com/article/Recipes/Fennel-Baked-in-Cream-Finocchio-al-Forno">Fennel Baked in Cream (Finocchio al Forno) Recipe - Saveur.com</a>
</span>
</li>
<li>
<span style="background-color: red">
<a target="link" href="">no link</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.365daysofkale.com/2009/02/recipe-spicy-lentil-sweet-potato.html">365 Days of Kale: Recipe: Spicy Lentil-Sweet Potato Patties with Kale</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.101cookbooks.com/archives/asparagus-stirfry-recipe.html">Asparagus Stir-Fry Recipe - 101 Cookbooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.realsimple.com/food-recipes/browse-all-recipes/curried-eggplant-tomatoes-basil-00000000011403/index.html">Curried Eggplant With Tomatoes And Basil</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.guardian.co.uk/lifeandstyle/2008/jul/05/recipe.foodanddrink">http://www.guardian.co.uk/lifeandstyle/2008/jul/05/recipe.foodanddrink</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.foodandwine.com/recipes/vegetables-with-walnut-dressing">http://www.foodandwine.com/recipes/vegetables-with-walnut-dressing</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thekitchn.com/thekitchn/quick/quick-recipe-udon-noodles-with-bok-choy-and-poached-egg-112043">Udon Soup with Bok Choy and Poached Egg | Apartment Therapy The Kitchn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.flex.com/~jai/articles/101.html">101 Reasons to go Vegetarian</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thehillthatbreathes.com/">The Hill That Breathes - Yoga and Alternative Holidays in Italy - Home page</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ezrapoundcake.com/archives/3547">Fresh Tomato Tart with a Basil-Garlic Crust</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://rogerebert.suntimes.com/apps/pbcs.dll/article?AID=/20110511/REVIEWS/110519995">Forks Over Knives :: rogerebert.com :: Reviews</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://veggiegalaxy.net/">Veggie Galaxy – Cambridge MA – Vegetarian Restaurant</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.wedipit.com/cooking-kenyan-food/">Cooking Kenyan Food - Kenyan Mahamri Cooking Recipe</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.vegancupcakerecipes.com/">Vegan Cupcake Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.delish.com/recipefinder/baked-penne-chicken-sun-dried-tomatoes-recipe-mslo1010">Baked Penne with Chicken and Sun-Dried Tomatoes Recipe ...</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.thekitchn.com/thekitchn/vegetable/kitchen-experiments-recreating-restaurant-sweet-potato-fries-122991">Trial and Error: Re-Creating Restaurant Sweet Potato Fries | Apartment Therapy The Kitchn</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://simplyrecipes.com/recipes/jamaican_rice_and_peas/">Jamaican Rice and Peas (Coconut Rice and Beans) Recipe | Simply Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.ecostyle24.it/">Lo stile di vita ecocompatibile | moda ecosostenibile, eco design, bioarchitettura, turismo ecologico | Ecostyle24</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.elanaspantry.com/roasted-banana-coconut-ice-cream/">Roasted Banana Coconut Ice Cream (Vegan and Gluten Free!) - Gluten Free Recipes | Elana's Pantry</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.101cookbooks.com/archives/how-to-make-gnocchi-like-an-italian-grandmother-recipe.html">How to Make Gnocchi like an Italian Grandmother Recipe - 101 Cookbooks</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.seriouseats.com/recipes/2010/09/cheese-sauce-for-cheese-fries-and-nachos.html">Cheese Sauce for Cheese Fries and Nachos | Serious Eats : Recipes</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://www.joythebaker.com/blog/2009/07/vegan-chocolate-avocado-cake/">Vegan Chocolate Avocado Cake — Joy the Baker</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://morethansalad.com/">More Than Salad</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://simplyrecipes.com/recipes/mushroom_risotto/">Mushroom Risotto</a>
</span>
</li>
<li>
<span style="background-color: lightgrey">
<a target="link" href="http://whiskflipstir.com/2010/10/04/general-tso-tofu/">General Tso’s Tofu « whisk flip stir</a>
</span>
</li>
</ol>
