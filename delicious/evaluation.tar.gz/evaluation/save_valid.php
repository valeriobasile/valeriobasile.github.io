<?

$db_file = "db/list.sqlite";
$table_name = "list";
$db = sqlite_open($db_file) or die("ERROR: Could not open database!"); 

foreach($_POST as $id => $value){
	$id = substr($id, 6);
	$sql = "update list set valid = $value where id = $id;";
	sqlite_query($db, $sql);
	
}

header("Location: evaluation_valid.php");
?>
